﻿using BA.Biocheck.Core.Common.Data;
using BA.Biocheck.Core.Common.EventArguments;
using BA.Biocheck.Core.Common.EventHandlers;
using BA.Biocheck.Core.Common.Exceptions;
using BA.Biocheck.Core.Common.Responses;
using BA.Biocheck.Core.Common.Util;
using BA.LogRegister;
using Neurotec;
using Neurotec.Biometrics;
using Neurotec.Biometrics.Client;
using Neurotec.Collections.ObjectModel;
using Neurotec.Devices;
using Neurotec.Images;
using Neurotec.IO;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace BA.Biocheck.Neurotechnology.v13
{
    public class BiometricFace
    {
        #region Properties
        //Se almacena globalmente la instruccion para no enviar instrucciones repetidas.
        private string InstructionActual = string.Empty;
        //Se almacena globalmente la fecha para generar un timer para el envio de imagenes
        private DateTime lastTime = DateTime.Now;
        public double milisecondspreview = 30;

        //Handler para mostrar Imagen en vivo
        public event DisplayImageEventHandler showPreview;
        public event DisplayInstructionsEventHandler showInstructions;
        public event DisplayAttributesEventHandler showAttributes;

        #endregion

        #region Public 
        /// <summary>
        /// Prueba de vida con instruccion definida
        /// </summary>
        /// <param name="instruction">Instrucciones a ejecutar</param>
        /// <param name="sndChance">Indica si es la primera o segunda vez que realiza la instrucción</param>
        /// <param name="config">Objeto con todos los umbrales para realizar la prueba de vida</param>
        /// <returns>Objeto con todos los datos de rostro</returns>
        public MethodResponse<DataFace> CaptureFaceLiveness(string instruction, ConfigUmbral config, bool sndChance)
        {
            var response = new MethodResponse<DataFace> { code = 0 };


            using (var _subject = new NSubject())
            using (var _face = new NFace())
            {
                var _faceData = new DataFace();
                var _biometricClient = new NBiometricClient();
                try
                {
                    // Usar el anministrador de dispositivos
                    _biometricClient.UseDeviceManager = true;
                    //
                    _biometricClient.FacesCheckIcaoCompliance = false;

                    //Configuracion del cliente
                    _biometricClient.Timeout = config.TimeOut;
                    _biometricClient.FacesMaximalYaw = config.FacesMaximalYaw;
                    _biometricClient.FacesMaximalRoll = config.FacesMaximalRoll;
                    if (!sndChance) //En el primer intento se utilizan los umbrales normales, en el segundo solo se ocupa una tercera parte de los umbrales
                    {
                        _biometricClient.FacesQualityThreshold = config.FacesQualityThreshold;
                        _biometricClient.FacesConfidenceThreshold = config.FacesConfidenceThreshold;
                        //_biometricClient.FacesSharpnessThreshold = config.FacesSharpnessThreshold;
                        _biometricClient.FacesLivenessThreshold = config.FacesLivenessThreshold;
                    }
                    else
                    {
                        _biometricClient.FacesQualityThreshold = (byte)Convert.ToInt32(config.FacesQualityThreshold / 3);
                        _biometricClient.FacesConfidenceThreshold = (byte)Convert.ToInt32(config.FacesConfidenceThreshold / 3);
                        //_biometricClient.FacesSharpnessThreshold = (byte)Convert.ToInt32(config.FacesSharpnessThreshold / 3);
                        _biometricClient.FacesLivenessThreshold = (byte)Convert.ToInt32(config.FacesLivenessThreshold / 3);
                    }
                    // Custom Liveness
                    _biometricClient.FacesLivenessMode = NLivenessMode.Custom;
                    //Opciones posibles turnRight,turnLeft,blink,delay
                    _biometricClient.SetProperty("Faces.LivenessCustomSequence", instruction);

                    //Obtener dispositivo a utilizar
                    _biometricClient = GetCamera(_biometricClient, config.NameDeviceValidation);

                    //Init Face Data
                    try
                    {
                        _faceData.Model = _biometricClient.FaceCaptureDevice.Model;
                    }
                    catch (Exception e)
                    {
                        Log.Print("Fallo [FaceData.Model = _biometricClient.FaceCaptureDevice.Model;] Se coloca Modelo genérico");
                        _faceData.Model = "Modelo Genérico";

                    }
                    try
                    {
                        _faceData.Serial = _biometricClient.FaceCaptureDevice.SerialNumber;
                    }
                    catch (Exception e)
                    {
                        Log.Print("Fallo [FaceData.Serial = _biometricClient.FaceCaptureDevice.SerialNumber] Se coloca Serial genérico");
                        _faceData.Serial = "Serial Genérico";
                    }
                    _faceData.Manufacturer = "Genérico";
                    Log.Print("Capturing from {0}. Please turn camera to face.", _biometricClient.FaceCaptureDevice.DisplayName);

                    // Define that the face source will be a stream
                    _face.CaptureOptions = NBiometricCaptureOptions.Stream;

                    //Asignar evento para obtener preview e instrucciones
                    _face.PropertyChanged += face_PropertyChanged;

                    // Add NFace to NSubject
                    _subject.Faces.Add(_face);


                    var status = _biometricClient.Capture(_subject);

                    _biometricClient.DeviceManager.Dispose();
                    if (status == NBiometricStatus.Ok)
                    {
                        // recorte de imagen Final para la prueba de vida
                        using (var image = _subject.Faces[0].Image)
                        {
                            _faceData.FaceImage = getRecordFromImg(image, NImageFormat.Png);
                            Log.LogImportant("<<Movimiento capturado>>");
                        }
                    }
                    else
                    {
                        switch (status)
                        {
                            case NBiometricStatus.Timeout:
                                throw new BiometricClassException("CaptureFaceCam TimeOut. Status : " + status, BiometricExceptions.TimeOut);
                            case NBiometricStatus.SpoofDetected:
                                throw new BiometricClassException("CaptureFaceCam SpoofDetected. Status : " + status, BiometricExceptions.SpoofDetected);
                            case NBiometricStatus.BadSharpness:
                                throw new BiometricClassException("CaptureFaceCam BadSharpness. Status : " + status, BiometricExceptions.BadSharpness);
                            case NBiometricStatus.BadPosition:
                                throw new BiometricClassException("CaptureFaceCam BadPosition. Status : " + status, BiometricExceptions.BadPosition);
                            default:
                                throw new BiometricClassException("CaptureFaceCam  default. Status: " + status, BiometricExceptions.UNKNOWN);
                        }
                    }



                    //Se asigna el result
                    response.result = _faceData;



                }
                catch (Neurotec.NeurotecException ex)
                {
                    Log.LogError("NeurotecException error: " + ex.ToString());
                    response.code = -301;
                    response.message = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                }
                catch (BiometricClassException ex)
                {
                    Log.LogError("BiometricClassException error: " + ex.InnerMessage);
                    response.code = (int)ex.Code;
                    response.message = ex.InnerMessage;
                    response.exception = ex;
                }
                catch (Exception ex)
                {
                    Log.LogError("Exception error: " + ex.ToString());
                    response.code = -300;
                    response.message = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                }
                finally
                {
                    //liberar memoria de objetos
                    _face.PropertyChanged -= face_PropertyChanged;
                    _biometricClient.DeviceManager.Dispose();
                    _biometricClient.FaceCaptureDevice.Dispose();
                    _face.Dispose();
                    _subject.Dispose();
                    _biometricClient.Dispose();
                }
            }
            return response;
        }

        /// <summary>
        /// Se obtiene imagen que cumple con las condiciones del ICAO
        /// </summary>
        /// <returns>Async Preview Image, Async Attributes ICAO</returns>
        public MethodResponse<DataFace> CaptureFaceICAO(ConfigUmbral config)
        {
            var response = new MethodResponse<DataFace> { code = 0 };

            using (var subject = new NSubject())

            using (var face = new NFace())
            {
                var _biometricClient = new NBiometricClient();
                try
                {
                    DataFace FaceData = new DataFace();
                    face.CaptureOptions = NBiometricCaptureOptions.Stream;

                    //Evento para obtener preview
                    face.PropertyChanged += face_PropertyChanged;
                    //Evento para iniciar el evento de atributos
                    face.Objects.CollectionChanged += OnObjectsCollectionChanged;

                    subject.Faces.Add(face);

                    _biometricClient.UseDeviceManager = true;
                    _biometricClient.FacesCheckIcaoCompliance = true;
                    _biometricClient.FacesDetectProperties = true;

                    //Configuracion del cliente
                    _biometricClient.Timeout = config.TimeOut;
                    _biometricClient.FacesMaximalYaw = config.FacesMaximalYaw;
                    _biometricClient.FacesMaximalRoll = config.FacesMaximalRoll;
                    _biometricClient.FacesQualityThreshold = config.FacesQualityThreshold;
                    _biometricClient.FacesConfidenceThreshold = config.FacesConfidenceThreshold;
                    _biometricClient.FacesLivenessThreshold = config.FacesLivenessThreshold;
                    //_biometricClient.FacesSharpnessThreshold = config.FacesSharpnessThreshold;

                    //Obtener dispositivo a utilizar
                    _biometricClient = GetCamera(_biometricClient, config.NameDeviceValidation);
                    Log.LogImportant("Se imprime biometric client:");
                    Log.LogImportant("_biometricClient: {0}", JsonConvert.SerializeObject(_biometricClient));
                    FaceData.Model = _biometricClient.FaceCaptureDevice.Model;
                    FaceData.Model = "Modelo Genérico";
                    FaceData.Serial = _biometricClient.FaceCaptureDevice.SerialNumber;
                    FaceData.Serial = "Serial Genérico";
                    FaceData.Manufacturer = "Genérico";

                    //Se crea tarea para obtner los atributos de manera asincrona
                    NBiometricTask task = _biometricClient.CreateTask(NBiometricOperations.Capture | NBiometricOperations.Segment, subject);
                    Log.Print("Se termina de ejecutar task\nContenido de task:");
                    Log.LogObject("{0}", task);
                    Log.Print("Estatus de Task:{0}", task.Status);

                    _biometricClient.PerformTask(task);
                    if (task.Status == NBiometricStatus.Ok)
                    {
                        //Response de proceso terminado
                        OnshowAttributes(new DisplayAttributesEventArgs(null, task.Status == NBiometricStatus.Ok));

#if LOCAL
                        //PruebaImprimirImagenes(subject.Faces);
#endif

                        using (var image = subject.Faces[1].Image)
                        {
                            FaceData.FaceImage = getRecordFromImg(image, NImageFormat.Jpeg);
                            FaceData.Hash = SHA256HexHashString(FaceData.FaceImage).ToUpper();
                            Log.Print("Image saved successfully");
                        }

                        FaceData.Status = "OK";
                        response.result = FaceData;
                    }
                    else if (task.Status == NBiometricStatus.Timeout)
                    {


                        response.code = (int)BiometricExceptions.TimeOut;
                        response.message = task.Status.ToString();
                    }
                    else
                    {
                        response.code = (int)BiometricExceptions.UNKNOWN;
                        response.message = task.Status.ToString();
                    }

                    response.result = FaceData;
                    Log.Print("Se termina Process-CaptureFaceICAO");
                    //return response;
                }

                catch (Neurotec.NeurotecException ex)
                {
                    Log.LogErrorObject(ex);
                    Log.LogError("NeurotecException error: " + ex.ToString());
                    response.code = -301;
                    response.message = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                }
                catch (BiometricClassException ex)
                {
                    Log.LogErrorObject(ex);
                    Log.LogError("BiometricClassException error: " + ex.InnerMessage);
                    response.code = (int)ex.Code;
                    response.message = ex.InnerMessage;
                    response.exception = ex;
                }
                catch (Exception ex)
                {
                    Log.LogErrorObject(ex);
                    Log.LogError("Exception error: {0}", ex.ToString());
                    response.code = -300;
                    response.message = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                }
                finally
                {

                    face.PropertyChanged -= face_PropertyChanged;
                    face.Objects.CollectionChanged -= OnObjectsCollectionChanged;
                    _biometricClient.FaceCaptureDevice.Dispose();
                    _biometricClient.DeviceManager.Dispose();
                    face.Dispose();
                    subject.Dispose();
                    try
                    {
                        Log.LogImportant("Se hace dispose del Biometric Client.");
                        _biometricClient.Dispose();
                    }
                    catch (Exception ex)
                    {
                        Log.LogError("No se logró dispose del Biometric Client.");
                        Log.LogError(ex.ToString());
                    }
                }
            }
            return response;
        }

#if LOCAL
        private void PruebaImprimirImagenes(NSubject.FaceCollection Faces)
        {
            int i = 0;
            foreach (var fac in Faces)
            {
                NImage fimage = fac.Image;
                Guid id = Guid.NewGuid();
                Log.LogImportant("Original [1] a {0}", id, i);
                Directory.CreateDirectory(@"c:\fotos\neuro");
                fimage.Save(String.Format(@"c:\fotos\neuro\{0}_{1}.jpeg", i, id), NImageFormat.Jpeg);
                i++;
            }
        }
#endif
        /// <summary>
        /// Realiza la extracción del rostro de una imagen y realia las validaciones de ojos, lentes, boca y umbrales.
        /// </summary>
        /// <returns> Datos del biométrico del rostro. </returns>
        public MethodResponse<DataFace> CheckICAOPhoto(DataFace photo, bool DetectErrors, ConfigUmbral config)
        {
            Log.Print("Se ejecuta Process-CheckICAOPhoto");
            var response = new MethodResponse<DataFace>();

            DataFace FaceData = photo;
            FaceData.Serial = "0";
            FaceData.Status = null;
            byte[] PhotoFace = FaceData.FaceImage;
            NImage Photo = NImage.FromMemory(PhotoFace);


            using (var biometricClient = new NBiometricClient())
            using (var subject = new NSubject())
            using (var face = new NFace())
            {
                try
                {
                    //Face image will be read from file
                    face.Image = Photo;
                    subject.Faces.Add(face);

                    // Set which features should be detected

                    biometricClient.FacesDetectAllFeaturePoints = true;
                    //biometricClient.FacesRecognizeExpression = true;
                    biometricClient.FacesDetectProperties = true;

                    biometricClient.FacesMaximalYaw = config.FacesMaximalYaw;
                    biometricClient.FacesMaximalRoll = config.FacesMaximalRoll;
                    biometricClient.FacesQualityThreshold = config.FacesQualityThreshold;
                    biometricClient.FacesConfidenceThreshold = config.FacesConfidenceThreshold;
                    biometricClient.FacesLivenessThreshold = config.FacesLivenessThreshold;

                    biometricClient.FacesCheckIcaoCompliance = true;
                    biometricClient.FacesTokenImageWidth = 300;

                    var task = biometricClient.CreateTask(NBiometricOperations.DetectSegments | NBiometricOperations.Segment | NBiometricOperations.AssessQuality, subject);

                    //Perform task
                    biometricClient.PerformTask(task);

                    NBiometricStatus status = task.Status;
                    if (status == NBiometricStatus.Ok)
                    {
                        Log.Print("face:[{0}]", JsonConvert.SerializeObject(face));
                        foreach (var attributes in face.Objects)
                        {
                            double avgFeature = 0;
                            bool blink = false, mouthOpen = false, darkGlasses = false, hat = false, glasses = false, lookingaway = false;
                            string message = string.Empty;
                            Log.Print("Attributes:[{0}]", JsonConvert.SerializeObject(attributes));
                            Log.Print("Confidence:[{0}]", JsonConvert.SerializeObject(attributes.FeaturePoints));
                            foreach (var featurePoint in attributes.FeaturePoints)
                            {
                                avgFeature += int.Parse(featurePoint.Confidence.ToString());
                            }
                            avgFeature = (avgFeature / attributes.FeaturePoints.Count);

                            if ((attributes.IcaoWarnings & NIcaoWarnings.DarkGlasses) == NIcaoWarnings.DarkGlasses)
                            {
                                darkGlasses = true;
                                Log.Print("\t\tDark glasses detected");
                                message += ", Dark glasses detected ";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.Blink) == NIcaoWarnings.Blink)
                            {
                                blink = true;
                                Log.Print("\t\tBlink detected");
                                message += "Blink detected ";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.MouthOpen) == NIcaoWarnings.MouthOpen)
                            {
                                mouthOpen = true;
                                Log.Print("\t\tMouth open detected");
                                message += ", Mouth open detected ";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.LookingAway) == NIcaoWarnings.LookingAway)
                            {
                                lookingaway = true;
                                Log.Print("\t\tLooking away detected");
                                message += ", Looking away detected ";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.GlassesReflection) == NIcaoWarnings.GlassesReflection)
                            {
                                glasses = true;
                                Log.Print("\t\tGlasses detected");
                                message += ", Glasses detected ";
                            }


                            if ((attributes.IcaoWarnings & NIcaoWarnings.FaceNotDetected) == NIcaoWarnings.FaceNotDetected)
                            {
                                message += $", {NIcaoWarnings.FaceNotDetected}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.RollLeft) == NIcaoWarnings.RollLeft)
                            {
                                message += $", {NIcaoWarnings.RollLeft}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.RollRight) == NIcaoWarnings.RollRight)
                            {
                                message += $", {NIcaoWarnings.RollRight}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.YawLeft) == NIcaoWarnings.YawLeft)
                            {
                                message += $", {NIcaoWarnings.YawLeft}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.YawRight) == NIcaoWarnings.YawRight)
                            {
                                message += $", {NIcaoWarnings.YawRight}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.PitchUp) == NIcaoWarnings.PitchUp)
                            {
                                message += $", {NIcaoWarnings.PitchUp}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.PitchDown) == NIcaoWarnings.PitchDown)
                            {
                                message += $", {NIcaoWarnings.PitchDown}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.TooNear) == NIcaoWarnings.TooNear)
                            {
                                message += $", {NIcaoWarnings.TooNear}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.TooFar) == NIcaoWarnings.TooFar)
                            {
                                message += $", {NIcaoWarnings.TooFar}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.TooNorth) == NIcaoWarnings.TooNorth)
                            {
                                message += $", {NIcaoWarnings.TooNorth}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.TooSouth) == NIcaoWarnings.TooSouth)
                            {
                                message += $", {NIcaoWarnings.TooSouth}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.TooEast) == NIcaoWarnings.TooEast)
                            {
                                message += $", {NIcaoWarnings.TooEast}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.TooWest) == NIcaoWarnings.TooWest)
                            {
                                message += $", {NIcaoWarnings.TooWest}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.Sharpness) == NIcaoWarnings.Sharpness)
                            {
                                message += $", {NIcaoWarnings.Sharpness}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.BackgroundUniformity) == NIcaoWarnings.BackgroundUniformity)
                            {
                                message += $", {NIcaoWarnings.BackgroundUniformity}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.GrayscaleDensity) == NIcaoWarnings.GrayscaleDensity)
                            {
                                message += $", {NIcaoWarnings.GrayscaleDensity}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.Saturation) == NIcaoWarnings.Saturation)
                            {
                                message += $", {NIcaoWarnings.Saturation}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.Expression) == NIcaoWarnings.Expression)
                            {
                                message += $", {NIcaoWarnings.Expression}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.RedEye) == NIcaoWarnings.RedEye)
                            {
                                message += $", {NIcaoWarnings.RedEye}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.FaceDarkness) == NIcaoWarnings.FaceDarkness)
                            {
                                message += $", {NIcaoWarnings.FaceDarkness}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.UnnaturalSkinTone) == NIcaoWarnings.UnnaturalSkinTone)
                            {
                                message += $", {NIcaoWarnings.UnnaturalSkinTone}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.WashedOut) == NIcaoWarnings.WashedOut)
                            {
                                message += $", {NIcaoWarnings.WashedOut}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.Pixelation) == NIcaoWarnings.Pixelation)
                            {
                                message += $", {NIcaoWarnings.Pixelation}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.SkinReflection) == NIcaoWarnings.SkinReflection)
                            {
                                message += $", {NIcaoWarnings.SkinReflection}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.HeavyFrame) == NIcaoWarnings.HeavyFrame)
                            {
                                message += $", {NIcaoWarnings.HeavyFrame}";
                            }
                            if ((attributes.IcaoWarnings & NIcaoWarnings.Liveness) == NIcaoWarnings.Liveness)
                            {
                                message += $", {NIcaoWarnings.Liveness}";
                            }



                            // Se recomienda agregar los nuevos elementos de analisis de rostro a su Enum BiometricExceptions

                            if ((blink || mouthOpen || darkGlasses || glasses || lookingaway) && DetectErrors)
                            {
                                Log.Print(message);
                                if (blink)
                                    throw new BiometricClassException("IdentifyFace Blink. Status : " + message, BiometricExceptions.Blink);
                                else if (mouthOpen)
                                    throw new BiometricClassException("IdentifyFace mouthOpen.  Status: " + message, BiometricExceptions.MouthOpen);
                                else if (darkGlasses)
                                    throw new BiometricClassException("IdentifyFace darkGlasses. Status : " + message, BiometricExceptions.FeatureDetected);
                                else if (hat)
                                    throw new BiometricClassException("IdentifyFace Hat. Status : " + message, BiometricExceptions.FeatureDetected);
                                else if (glasses)
                                    throw new BiometricClassException("IdentifyFace Glasses. Status : " + message, BiometricExceptions.FeatureDetected);
                                else if (lookingaway)
                                    throw new BiometricClassException("IdentifyFace Looking Away. Status : " + message, BiometricExceptions.FeatureDetected);
                            }
                            else
                            {
                                Log.Print($"OK , FeaturepointsConfidence: {avgFeature} DetectionConfidence: { attributes.DetectionConfidence}");
                                using (var image = subject.Faces[0].Image)
                                {
                                    FaceData.FaceImage = getRecordFromImg(image, NImageFormat.Jpeg);
#if LOCAL
                                    PruebaImprimirImagenes(subject.Faces);
#endif

                                    FaceData.Hash = SHA256HexHashString(FaceData.FaceImage).ToUpper();
                                    Log.Print("image saved successfully");
                                }
                                FaceData.Status = "OK";
                                response.result = FaceData;
                            }

                        }
                    }
                    else
                    {
                        foreach (NLAttributes item in face.Objects.ToArray())
                        {
                            Log.Print(item.ToString());
                        }

                        Log.Print("CheckICAOphoto Status = {0}", status);
                        switch (status)
                        {
                            case NBiometricStatus.BadSharpness:
                                throw new BiometricClassException("IdentifyFace BadSharpness. Status : " + status, BiometricExceptions.BadSharpness);
                            default:
                                throw new BiometricClassException("IdentifyFace  default. Status: " + status, BiometricExceptions.UNKNOWN);
                        }
                    }

                    //NLicense.ReleaseComponents(Components);
                    //License.Release();

                    response.result = FaceData;
                }
                catch (BiometricClassException ex)
                {
                    Log.LogError("BiometricClassException CheckICAOPhoto: " + ex.InnerMessage);
                    response.code = (int)ex.Code;
                    response.message = ex.InnerMessage;
                    //response.exception = ex;
                }
                catch (Exception ex)
                {
                    Log.LogError("Exception CheckICAOPhoto: " + ex.ToString());
                    response.code = -300;
                    response.message = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                }
                finally
                {
                    face.Dispose();
                    subject.Dispose();
                    biometricClient.Dispose();
                }
            }

            return response;

        }
        #endregion

        #region Private
        /// <summary>
        /// Obtiene la camara para el proceso
        /// </summary>
        /// <param name="BiometricClient">Biometric Client actual</param>
        /// <returns>biometric cliente con el dispositivo asignado</returns>
        private NBiometricClient GetCamera(NBiometricClient BiometricClient, string NameValidation)
        {
            NDeviceManager DeviceManager = BiometricClient.DeviceManager;
            try
            {
                DeviceManager.DeviceTypes = NDeviceType.Camera;
                DeviceManager.Initialize();

                using (NCamera CurrentDevice = null)
                {
                    BiometricClient.FaceCaptureDevice = (NCamera)SearchDevice(CurrentDevice, DeviceManager, NameValidation);
                }

                return BiometricClient;

            }
            catch (BiometricClassException ex)
            {
                DeviceManager.Dispose();
                Log.LogError("!!Error on GetCamera: " + ex.Message.ToString());
                ex.InnerMessage = "No se detectaron dispositivos.";
                throw (ex);
            }

        }
        /// <summary>
        /// Busca la camara entre los dipositivos conectados 
        /// </summary>
        /// <param name="CurrentDevice"></param>
        /// <param name="DeviceManager"></param>
        /// <param name="NameValidation">Validacion de dispositivo en especifico</param>
        /// <returns></returns>
        private NCaptureDevice SearchDevice(NCaptureDevice CurrentDevice, NDeviceManager DeviceManager, string NameValidation)
        {
            try
            {
                if (DeviceManager.Devices.Count > 0)
                {
                    Log.Print(">>Found : " + DeviceManager.Devices.Count + " devices.");
                    foreach (NDevice device in DeviceManager.Devices)
                    {
                        if (!string.IsNullOrEmpty(NameValidation) && device.DisplayName.IndexOf(NameValidation) != -1)
                        {
                            CurrentDevice = (NCaptureDevice)device;
                            break;
                        }
                        else
                            CurrentDevice = (NCaptureDevice)device;

                    }

                    if (CurrentDevice != null)
                    {
                        Log.Print(">>Device to use -> {0} - {1} ", CurrentDevice.DisplayName, CurrentDevice.Model);
                        return CurrentDevice;
                    }
                    else
                    {
                        Log.LogError(">>SearchDevice -> No se detectaron lectores {0}.", NameValidation);
                        throw (new BiometricClassException("", BiometricExceptions.NoDevice));
                    }
                }
                else
                {
                    Log.LogError(">>SearchDevice -> No se detectaron lectores.");
                    throw (new BiometricClassException("", BiometricExceptions.NoDevice));
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// Regeresa el template solicitado de la imagen.
        /// </summary>
        /// <param name="fimage"> Imagen del biométrico. </param>
        /// <param name="format"> Formato solicitado. </param>
        /// <returns> Template en formato solicitado. </returns>
        private byte[] getRecordFromImg(NImage fimage, NImageFormat format)
        {

            if (format == NImageFormat.Jpeg)
            {
#if LOCAL

                Guid id = Guid.NewGuid();
                //Log.LogImportant("Original a {0}", id);
                //fimage.Save(@"c:\fotos\" + id + ".bmp", NImageFormat.Bmp);
#endif
                NBuffer imgBuff = fimage.Save(NImageFormat.Bmp);

                using (var ms = new MemoryStream(imgBuff.ToArray()))
                {
                    Image inputImage = Bitmap.FromStream(ms);
                    using (var stream = new MemoryStream())
                    {
                        int width = 480;//
                        int height = 640;//

                        Bitmap resized = new Bitmap(inputImage, new Size(width, height));
                        resized.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);
                        // Dispose the graphics object

                        NImage imgGemal = NImage.FromMemory(stream.ToArray());
#if LOCAL
                        id = Guid.NewGuid();
                        Log.LogImportant("resize a {0}", id);
                        Directory.CreateDirectory(@"c:\fotos\");
                        imgGemal.Save(@"c:\fotos\" + id + ".jpeg", NImageFormat.Jpeg);
#endif
                        NBuffer buffer = imgGemal.Save(NImageFormat.Jpeg);
                        inputImage.Dispose();
                        return buffer.ToArray();
                    }


                }
            }
            else if (format == NImageFormat.Bmp)
            {
                // Create blank image
                int x = (int)fimage.Width;
                int y = (int)fimage.Height;
                Bitmap bitmap = new Bitmap(416, 416);
                using (Graphics graph = Graphics.FromImage(bitmap))
                {
                    Rectangle ImageSize = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
                    graph.FillRectangle(Brushes.White, ImageSize);
                }
                // Create graphics object on that image
                Graphics graphics = Graphics.FromImage(bitmap);

                NBuffer imgBuff = fimage.Save(NImageFormat.Bmp);
                using (var ms = new MemoryStream(imgBuff.ToArray()))
                {
                    Image inputImage = Bitmap.FromStream(ms);
                    Bitmap bmpfinger = new Bitmap(x, 416);

                    Graphics g = Graphics.FromImage(bmpfinger);

                    // Draw the given area (section) of the source image
                    // at location 0,0 on the empty bitmap (bmp)
                    g.DrawImage(inputImage, 0, 0, x, y);
                    // Load an image from existing file
                    graphics.DrawImage(bmpfinger, (416 - x) / 2, 0, x, 416);

                    // save the created image
                    using (var stream = new MemoryStream())
                    {
                        bitmap.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);
                        // Dispose the graphics object
                        NImage imgGemal = NImage.FromMemory(stream.ToArray());
                        imgGemal = NImage.FromImage(NPixelFormat.Grayscale8S, 0, imgGemal);
                        NBuffer buffer = imgGemal.Save(NImageFormat.Bmp);
                        graphics.Dispose();

                        // Dispose the images
                        bitmap.Dispose();
                        inputImage.Dispose();
                        return buffer.ToArray();
                    }


                }
            }
            else if (format == NImageFormat.Jpeg2K)
            {
                NBuffer imgBuff = fimage.Save(NImageFormat.Bmp);
                return imgBuff.ToArray();
            }
            else
            {
                NBuffer imgBuff = fimage.Save(format);
                return imgBuff.ToArray();
            }
        }
        private string SHA256HexHashString(byte[] wsq)
        {
            using (var sha256 = SHA256Managed.Create())
            {
                var hash = sha256.ComputeHash(wsq);
                return ToHex(hash, false);
            }
        }
        private string ToHex(byte[] bytes, bool upperCase)
        {
            StringBuilder result = new StringBuilder(bytes.Length * 2);
            for (int i = 0; i < bytes.Length; i++)
                result.Append(bytes[i].ToString(upperCase ? "X2" : "x2"));
            return result.ToString();
        }
        #endregion

        #region Events
        /// <summary>
        /// Metodo de invocación del oevento de preview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void face_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            NFace f = (NFace)sender;
            if (f.Objects.Count > 0)
            {
                //valida si la instruccion a enviar es la misma que la ultima enviada
                if (!InstructionActual.Contains(f.Objects[0].LivenessAction.ToString()))
                {
                    //if (!f.Objects[0].LivenessAction.ToString().ToLowerInvariant().Contains("none"))
                    //{
                    InstructionActual = f.Objects[0].LivenessAction.ToString();
                    OnshowInstructions(new DisplayInstructionsEventArgs("0", "0", InstructionActual));
                    Log.Print(">>>>------> Instruccion : " + InstructionActual);
                    //}

                }
            }
            if (f.Image != null)
            {
                //Impide que se envie una nueva peticion si aun no se cumple el numero de milisegundos indicado
                if (DateTime.Now.Subtract(lastTime).TotalMilliseconds > milisecondspreview)
                {

                    using (var stm = new MemoryStream())
                    {
                        //Convertir imagen a jpg para reducir el tamaño
                        f.Image.ToBitmap().Save(stm, ImageFormat.Jpeg);

                        //Guardado local de imagen
                        //f.Image.Save($"D://ImagePrueba/{Guid.NewGuid()}.jpeg");

                        // Convert byte[] to Base64 String
                        //string base64String = Convert.ToBase64String(stm.ToArray());

                        //Activar evento de preview
                        OnshowPreview(new DisplayImageEventArgs(stm.ToArray()));
                    }
                    lastTime = DateTime.Now;
                }

            }

        }
        private void OnObjectsCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == NotifyCollectionChangedAction.Add)
            {
                var objectCollection = (NFace.ObjectCollection)sender;
                var _attributes = objectCollection.ToArray().FirstOrDefault();
                if (_attributes != null)
                {
                    _attributes.PropertyChanged += OnAttributesPropertyChanged;
                }

            }
        }
        private void OnAttributesPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "IcaoWarnings")
            {
                var _attributes = (NLAttributes)sender;

                var attributesICAO = new AttributesICAO();

                if (_attributes != null)
                {
                    var warnings = _attributes.IcaoWarnings;

                    //Rostro no encontrado
                    attributesICAO.FaceDetected = (warnings & NIcaoWarnings.FaceNotDetected) == NIcaoWarnings.FaceNotDetected;

                    //Gestos
                    attributesICAO.Expression = (warnings & NIcaoWarnings.Expression) == NIcaoWarnings.Expression;
                    attributesICAO.Blink = (warnings & NIcaoWarnings.Expression) == NIcaoWarnings.Expression;
                    attributesICAO.MouthOpen = (warnings & NIcaoWarnings.MouthOpen) == NIcaoWarnings.MouthOpen;
                    attributesICAO.LookingAway = (warnings & NIcaoWarnings.LookingAway) == NIcaoWarnings.LookingAway;

                    //Imagen
                    attributesICAO.RedEye = (warnings & NIcaoWarnings.RedEye) == NIcaoWarnings.RedEye;
                    attributesICAO.FaceDarkness = (warnings & NIcaoWarnings.FaceDarkness) == NIcaoWarnings.FaceDarkness;
                    attributesICAO.UnnaturalSkinTone = (warnings & NIcaoWarnings.UnnaturalSkinTone) == NIcaoWarnings.UnnaturalSkinTone;
                    attributesICAO.ColorsWashedOut = (warnings & NIcaoWarnings.WashedOut) == NIcaoWarnings.WashedOut;
                    attributesICAO.Pixelation = (warnings & NIcaoWarnings.Pixelation) == NIcaoWarnings.Pixelation;
                    attributesICAO.SkinReflection = (warnings & NIcaoWarnings.SkinReflection) == NIcaoWarnings.SkinReflection;

                    //Articulos

                    //attributesICAO.Hat = (warnings & NLProperties.Hat) == NLProperties.Hat;
                    attributesICAO.DarkGlasses = (warnings & NIcaoWarnings.DarkGlasses) == NIcaoWarnings.DarkGlasses;
                    attributesICAO.GlassesReflection = (warnings & NIcaoWarnings.GlassesReflection) == NIcaoWarnings.GlassesReflection;

                    // Posición del rostro
                    attributesICAO.RollLeft = (warnings & NIcaoWarnings.RollLeft) == NIcaoWarnings.RollLeft;
                    attributesICAO.RollRight = (warnings & NIcaoWarnings.RollRight) == NIcaoWarnings.RollRight;

                    attributesICAO.YawRight = (warnings & NIcaoWarnings.YawRight) == NIcaoWarnings.YawRight;
                    attributesICAO.YawLeft = (warnings & NIcaoWarnings.YawLeft) == NIcaoWarnings.YawLeft;

                    attributesICAO.PitchUp = (warnings & NIcaoWarnings.PitchUp) == NIcaoWarnings.PitchUp;
                    attributesICAO.PitchDown = (warnings & NIcaoWarnings.PitchDown) == NIcaoWarnings.PitchDown;

                    attributesICAO.TooNear = (warnings & NIcaoWarnings.TooNear) == NIcaoWarnings.TooNear;
                    attributesICAO.TooFar = (warnings & NIcaoWarnings.TooFar) == NIcaoWarnings.TooFar;
                    attributesICAO.TooNorth = (warnings & NIcaoWarnings.TooNorth) == NIcaoWarnings.TooNorth;
                    attributesICAO.TooSouth = (warnings & NIcaoWarnings.TooSouth) == NIcaoWarnings.TooSouth;
                    attributesICAO.TooWest = (warnings & NIcaoWarnings.TooWest) == NIcaoWarnings.TooWest;
                    attributesICAO.TooEast = (warnings & NIcaoWarnings.TooEast) == NIcaoWarnings.TooEast;

                    //Condiciones generales
                    attributesICAO.Sharpness = (warnings & NIcaoWarnings.Sharpness) == NIcaoWarnings.Sharpness;
                    attributesICAO.Saturation = (warnings & NIcaoWarnings.Saturation) == NIcaoWarnings.Saturation;
                    attributesICAO.GrayscaleDensity = (warnings & NIcaoWarnings.GrayscaleDensity) == NIcaoWarnings.GrayscaleDensity;
                    attributesICAO.BackgroundUniformity = (warnings & NIcaoWarnings.BackgroundUniformity) == NIcaoWarnings.BackgroundUniformity;

                    //Logger.Log("Warnings {0}", warnings);
                    OnshowAttributes(new DisplayAttributesEventArgs(attributesICAO, false));

                }
                else
                {
                    attributesICAO.FaceDetected = true;
                    OnshowAttributes(new DisplayAttributesEventArgs(attributesICAO, false));
                }

            }
            //EnviarMensaje
        }

        public virtual void OnshowInstructions(DisplayInstructionsEventArgs e)
        {
            if (showInstructions != null)
                showInstructions(this, e);
        }
        public virtual void OnshowPreview(DisplayImageEventArgs e)
        {
            if (showPreview != null)
                showPreview(this, e);
        }
        public virtual void OnshowAttributes(DisplayAttributesEventArgs e)
        {
            if (showAttributes != null)
                showAttributes(this, e);
        }
        #endregion

    }
}
