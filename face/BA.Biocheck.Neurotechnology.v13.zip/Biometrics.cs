﻿using System;
using System.IO;
using System.Diagnostics;
using System.Linq;
using Neurotec.Licensing;
using Neurotec.Devices;
using Neurotec.Biometrics;
using Neurotec.Biometrics.Client;
using Neurotec.Images;
using Neurotec.Images.Processing;
using Neurotec.IO;
using System.Collections.Generic;
using System.Threading;
using BA.Biocheck.Core.Common.Data;
using BA.Biocheck.Core.Common.EventHandlers;
using System.Drawing;
using BA.Biocheck.Core.Common.EventArguments;
using System.Text;
using System.Threading.Tasks;
using Neurotec.Biometrics.Standards;
using System.Security.Cryptography;
using System.Xml.Serialization;
using BA.Biocheck.Core.Common.Exceptions;
using BA.Biocheck.Core.Common.Util;
using BA.LogRegister;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Drawing.Imaging;
using Neurotec;

namespace BA.Biocheck.Neurotechnology.v13
{
    public class Biometrics
    {
        #region Private Propreties
        private Bitmap sampleImage;
        private int RotateDirection = 0;
        private char[] graphic = new char[61];
        #endregion

        #region Public

        /// <summary>
        /// Evento para obtener el preview de la captura de huellas o prueba de vida (La prueba de vida se ha pasado a BiometricFace.cs)
        /// </summary>
        public event DisplayImageEventHandler showPreview;
        /// <summary>
        /// Evento para obtener las instrucciones de la prueba de vida (La prueba de vida se ha pasado a BiometricFace.cs)
        /// </summary>
        public event DisplayInstructionsEventHandler showInstructions;
        public NBiometricClient _biometricClient { get; set; }

        private static List<NLAttributes> monitorredAtributes = new List<NLAttributes>();

        public Biometrics()
        {
            Log.Print("Entra a Biometrics");


        }

        #region Capture Functions
        /// <summary>
        /// Realiza la captura del la huella y sus templates.
        /// </summary>
        /// <param name="pos"> Posición de la huella. </param>
        /// <param name="fingers"> Lista de templates por huella. </param>
        /// <param name="esEscanerUnidactilar"> Indica si se está capturando la huella con un escaner unidactilar </param>
        public void CaptureFingers(int pos, List<DataFinger> fingers, bool esEscanerUnidactilar, bool FingersDetectLiveness, string FingersLivenessConfidenceThreshold)
        {
            var fingerScannerRegex = !esEscanerUnidactilar ? @"KOJAK|WATSON" : @"U\.are\.U|COLUMBO";
            EventHandler<NBiometricDeviceCapturePreviewEventArgs> PreviewEvent = new EventHandler<NBiometricDeviceCapturePreviewEventArgs>(NFScanner_Preview);
            var biometricClient = new NBiometricClient();

            //biometricClient.Initialize();
            using (var subject = new NSubject())
            using (var finger = new NFinger())
            {
                try
                {
                    //Esta lista almacenará los id-posicion de las huellas que se deben de capturar, para en caso de una captura fallida
                    //saber cual fue la o las huellas de mala calidad
                    List<int> Posiciones = new List<int>();
                    #region De acuerdo a las huellas que se van a capturar, agregamos a una lista los id-posicion, de los dedos que deben de ser capturados
                    // Cuando la posición es menor o igual a 10 solo va a ser un dedo
                    if (pos <= 10)
                        Posiciones.Add(pos);
                    else
                        switch (pos) //Para ver todas las combinaciones de huellas ver enum de Neuro
                        {
                            case 15:
                                Posiciones.Add(1);
                                Posiciones.Add(6);
                                break;
                            case 40:
                                Posiciones.Add(2);
                                Posiciones.Add(3);
                                break;
                            case 43:
                                Posiciones.Add(7);
                                Posiciones.Add(8);
                                break;
                            case 47:
                                Posiciones.Add(2);
                                Posiciones.Add(3);
                                Posiciones.Add(4);
                                break;
                            case 48:
                                Posiciones.Add(3);
                                Posiciones.Add(4);
                                Posiciones.Add(5);
                                break;
                            case 49:
                                Posiciones.Add(7);
                                Posiciones.Add(8);
                                Posiciones.Add(9);
                                break;
                            case 50:
                                Posiciones.Add(8);
                                Posiciones.Add(9);
                                Posiciones.Add(10);
                                break;
                            case 13:
                                Posiciones.Add(2);
                                Posiciones.Add(3);
                                Posiciones.Add(4);
                                Posiciones.Add(5);
                                break;
                            case 14:
                                Posiciones.Add(7);
                                Posiciones.Add(8);
                                Posiciones.Add(9);
                                Posiciones.Add(10);
                                break;

                        }
                    #endregion
                    #region Realizamos la configuración del escaner

                    biometricClient.UseDeviceManager = true;
                    biometricClient.FingersFastExtraction = false;
                    biometricClient.FingersCalculateNfiq2 = false;
                    biometricClient.FingersCalculateNfiq21 = false;
                    biometricClient.FingersCalculateNfiq = true;
                    biometricClient.Timeout = new TimeSpan(0, 0, 30);


                    #region PARAMETROS AUDITORIA DEFINICION
                    biometricClient.FingersDetectLiveness = FingersDetectLiveness ? FingersDetectLiveness : true;
                    int value = string.IsNullOrEmpty(FingersLivenessConfidenceThreshold) ? 100 : int.Parse(FingersLivenessConfidenceThreshold);
                    biometricClient.FingersLivenessConfidenceThreshold = (byte)value;
                    #endregion


                    //biometricClient.FingersDeterminePatternClass = true;
                    biometricClient.FingersTemplateSize = NTemplateSize.Small;
                    biometricClient.FingersReturnBinarizedImage = false;
                    biometricClient = GetDevice(NDeviceType.FingerScanner, biometricClient, fingerScannerRegex);

                    if (biometricClient.FingerScanner != null)
                        Log.Print(">>Device to use -> {0} - {1} ", biometricClient.FingerScanner.DisplayName, biometricClient.FingerScanner.Model);


                    else

                        #region PARAMETROS AUDITORIA LOG
                        biometricClient.FingerScanner.SpoofDetection = false;
                    bool si = biometricClient.FingerScanner.IsSpoofDetectionSupported;
                    Log.Print("El dispositivo conectado soporta spoofDetection?" + si);
                    Log.Print("FingersDetectLiveness activo?" + biometricClient.FingersDetectLiveness);
                    Log.Print("FingersLivenessConfidenceThreshold umbral?" + biometricClient.FingersLivenessConfidenceThreshold);
                    #endregion

                    biometricClient.FingerScanner.CapturePreview += PreviewEvent;

                    NFPosition nfPosition = (NFPosition)pos;
                    finger.Position = nfPosition;
                    subject.Fingers.Add(finger);

                    #endregion
                    Log.Print("-Waiting for Finger: " + nfPosition.ToString());
                    //Capturamos las huellas
                    #region Si algo no salió bien la captura, lo informamos al front
                    var status = biometricClient.Capture(subject);

                    if (status != NBiometricStatus.Ok)
                    {
                        Log.Print("Failed to capture: " + status);
                        switch (status)
                        {
                            case NBiometricStatus.Timeout:
                                throw new BiometricClassException("CaptureFingers TimeOut. Status : " + status, BiometricExceptions.TimeOut);
                            case NBiometricStatus.BadObject:
                            case NBiometricStatus.TooFewObjects:
                                throw new BiometricClassException("CaptureFingers BadObject. Status : " + status, BiometricExceptions.BadObject);
                        }
                    }
                    #endregion
                    Log.Print("Huellas escaneadas");


                    NBiometricTask task = null;
                    if (esEscanerUnidactilar) //Indica si la captura se realizó con un kojak para saber si segmentar o no.
                    {
                        Log.Print("Task: CreateTemplate");
                        task = biometricClient.CreateTask(NBiometricOperations.CreateTemplate | NBiometricOperations.AssessQuality, subject);
                    }
                    else
                    {//En caso de que sea un decadactilar (Kojak) realizamos la segmentación
                        Log.Print("Task: Segment | CreateTemplate");
                        task = biometricClient.CreateTask(NBiometricOperations.Segment | NBiometricOperations.CreateTemplate | NBiometricOperations.AssessQuality, subject);
                    }

                    biometricClient.PerformTask(task);

                    CreateFingers(pos, fingers, subject, nfPosition, biometricClient, esEscanerUnidactilar);

                    //Con alguna huella que haya salido mal capturada, el "task.Status" va a ser diferente a Ok
                    if (task.Status == NBiometricStatus.Ok)
                    {
                        Log.Print("Capture status: " + task.Status);
                        Log.Print("Template extracted");
                        Log.Print("FingersDetectLiveness " + biometricClient.FingersDetectLiveness);
                        Log.Print("FingersLivenessConfidenceThreshold " + biometricClient.FingersLivenessConfidenceThreshold);
                    }
                    else
                    {
                        List<DataFinger> MissingList = new List<DataFinger>();
                        Log.Print("Capture status: " + task.Status);
                        Log.Print("Capture FingersLivenessConfidenceThreshold umbral: " + biometricClient.FingersLivenessConfidenceThreshold);
                        //El estatus será igual a badObject cuando se captura cualquier huella con mala calidad
                        if (task.Status == NBiometricStatus.BadObject)
                        {
                            //Seteamos todas las huellas que hayan salido con mala calidad
                            foreach (DataFinger x in fingers)
                            {
                                if (SingleFingerTemplates(biometricClient, x.Jpeg2000))
                                    x.BadCapture = true;
                            }
                        }

                        //En ocaciones cuando la captura de algunas huellas es pesima el escaner ni siquiera la trae en la lista
                        //En esta sección buscamos y agregamos las huellas no hayan sido capturadas en por el escaner, poniendolas con el estatus de "BadCapture"
                        foreach (int id in Posiciones)
                        {
                            if (!fingers.Any(h => h.Position == id))
                            {
                                DataFinger faltante = new DataFinger();
                                faltante.Position = id;
                                faltante.BadCapture = true;
                                fingers.Add(faltante);
                            }

                        }
                    }
                }
                catch (Neurotec.NeurotecException ex)
                {
                    Log.Print("Capture fingers error: " + ex.ToString());
                    throw (ex);
                }
                //catch(Neurotec.AggregateException ex)
                //{
                //    throw new BiometricClassException("CaptureFingers: Se desconecto el dispositivo en medio de la captura.", BiometricExceptions.DeviceDisconnected);
                //}
                catch (BiometricClassException ex)
                {
                    throw (ex);
                }
                catch (Exception ex)
                {
                    throw (ex);
                }
                finally
                {
                    if (biometricClient.FingerScanner != null)
                    {
                        biometricClient.FingerScanner.CapturePreview -= PreviewEvent;
                        biometricClient.FingerScanner.Dispose();
                    }
                    if (biometricClient.DeviceManager != null)
                        biometricClient.DeviceManager.Dispose();

                    subject.Dispose();
                    finger.Dispose();
                    biometricClient.Dispose();

                    Log.LogImportant("Dispose de todos los objetos.");
                }
            }
        }

        /// <summary>
        /// Realiza la captura del la huella y sus templates.
        /// </summary>
        /// <param name="pos"> Posición de la huella. </param>
        /// <param name="Irises"> Lista de templates por huella. </param>
        public byte[] CaptureIrises(int pos, List<DataIris> Irises)
        {
            byte[] BMP = null;
            try
            {
                // License.Get(Components);

                var biometricClient = new NBiometricClient();
                using (var subject = new NSubject())
                using (var finger = new NIris())
                {
                    EventHandler<NBiometricDeviceCapturePreviewEventArgs> PreviewEvent = new EventHandler<NBiometricDeviceCapturePreviewEventArgs>(NIrisScanner_Preview);
                    biometricClient.UseDeviceManager = true;
                    biometricClient.FingersFastExtraction = false;
                    biometricClient.Timeout = new TimeSpan(0, 0, 30);
                    biometricClient.IrisesTemplateSize = NTemplateSize.Large;
                    //biometricClient.FingersCalculateNfiq = true;
                    biometricClient = GetDevice(NDeviceType.FingerScanner, biometricClient);
                    biometricClient.IrisScanner.CapturePreview += PreviewEvent;
                    NEPosition nePosition = (NEPosition)pos;
                    finger.Position = nePosition;
                    subject.Irises.Add(finger);
                    //start capturing
                    Log.Print("Waiting for Iris: " + nePosition.ToString());
                    NBiometricStatus status = biometricClient.Capture(subject);
                    if (status != NBiometricStatus.Ok)
                    {
                        Log.Print("Failed to capture: " + status);
                        throw new Exception("Failed to capture: " + status);
                    }

                    //Create template from added finger image
                    status = biometricClient.CreateTemplate(subject);
                    if (status == NBiometricStatus.Ok)
                    {
                        Log.Print("Template extracted");
                        BMP = CreateIris(pos, Irises, subject, nePosition, biometricClient, BMP);
                    }
                    else
                    {
                        Log.Print("Extraction failed! Status: {0}", status);
                        throw new Exception("Extraction failed! Status: " + status);
                    }
                    //NLicense.ReleaseComponents(Components);
                    //License.Release();

                }
                return BMP;
            }
            catch (Exception ex)
            {
                //NLicense.ReleaseComponents(Components);
                //License.Release();

                Log.Print("Capture Iris error: " + ex.ToString());
                throw (ex);
            }
        }

        /// <summary>
        /// Realiza la captura del rostro con la webcam.
        /// </summary>
        /// <returns> Datos del biométrico del rostro. </returns>
        ///
        public DataFace CaptureFaceCam(bool IsLiveness)
        {
            DataFace FaceData = new DataFace();
            try
            {
                using (var subject = new NSubject())
                using (var face = new NFace())
                {

                    EventHandler<EventArgs> FaceEvent = new EventHandler<EventArgs>(NCamera_Preview);
                    _biometricClient = new NBiometricClient();
                    _biometricClient.UseDeviceManager = true;


                    if (IsLiveness)
                    {
                        //Guiño maximo
                        _biometricClient.FacesMaximalYaw = 90;
                        //El umbral de calidad de las caras
                        _biometricClient.FacesQualityThreshold = 10;
                        //_biometricClient.FacesLivenessThreshold = 10;
                        #region Follow Target
                        //_biometricClient.FacesLivenessMode = NLivenessMode.Active;
                        #endregion
                        #region Custom Liveness
                        //_biometricClient.FacesLivenessMode = NLivenessMode.Active;
                        _biometricClient.FacesLivenessMode = NLivenessMode.Custom;
                        _biometricClient.SetProperty("Faces.LivenessCustomSequence", "blink,delay");
                        //_biometricClient.SetProperty("Faces.LivenessCustomSequence", "blink,turnLeft,turnRight,delay");
                        //_biometricClient.SetProperty("Faces.LivenessCustomSequence", "turnRight,turnLeft,delay");
                        ////Giro maximo
                        //_biometricClient.FacesMaximalRoll = 180;
                        ////Guiño maximo
                        //_biometricClient.FacesMaximalYaw = 90;
                        //El umbral de confianza de las caras
                        _biometricClient.FacesConfidenceThreshold = 50;

                        ////Caras Umbral de nitidez
                        //_biometricClient.FacesSharpnessThreshold = 0;


                        #endregion
                    }
                    Log.Print(@"------Inicio Captura {0}", DateTime.Now.ToString());
                    _biometricClient.Timeout = new TimeSpan(0, 0, 45);
                    _biometricClient = GetDevice(NDeviceType.Camera, _biometricClient);
                    _biometricClient.FaceCaptureDevice.IsCapturingChanged += FaceEvent;

                    FaceData.Model = _biometricClient.FaceCaptureDevice.Model;
                    FaceData.Serial = _biometricClient.FaceCaptureDevice.SerialNumber;
                    FaceData.Manufacturer = "Genérico";
                    Log.Print("Capturing from {0}. Please turn camera to face.", _biometricClient.FaceCaptureDevice.DisplayName);

                    // Define that the face source will be a stream
                    face.CaptureOptions = NBiometricCaptureOptions.Stream;

                    #region PRUEBA MARTYNAS
                    if (IsLiveness)
                    {
                        face.PropertyChanged += face_PropertyChanged;
                        face.Objects.CollectionChanged += Objects_CollectionChanged;
                        //foreach (NLAttributes item in face.Objects.ToArray())
                        //{
                        //    Logger.Log(item.ToString());
                        //    monitorredAtributes.Add(item);
                        //    item.PropertyChanged += attributes_PropertyChanged;
                        //}
                    }
                    #endregion

                    // Add NFace to NSubject
                    subject.Faces.Add(face);


                    var status = _biometricClient.Capture(subject);

                    _biometricClient.FaceCaptureDevice.IsCapturingChanged -= FaceEvent;
                    if (status == NBiometricStatus.Ok)
                    {
                        using (var image = subject.Faces[0].Image)
                        {
                            FaceData.FaceImage = getRecordFromImg(image, NImageFormat.Png);
                            Log.Print("image saved successfully");
                            FaceData.Status = "Ok";
                        }
                    }
                    else
                    {
                        Log.Print("Failed to capture: " + status);
                        switch (status)
                        {
                            case NBiometricStatus.Timeout:
                                throw new BiometricClassException("CaptureFaceCam TimeOut. Status : " + status, BiometricExceptions.TimeOut);
                            case NBiometricStatus.SpoofDetected:
                                throw new BiometricClassException("CaptureFaceCam SpoofDetected. Status : " + status, BiometricExceptions.SpoofDetected);
                            case NBiometricStatus.BadSharpness:
                                throw new BiometricClassException("CaptureFaceCam BadSharpness. Status : " + status, BiometricExceptions.BadSharpness);
                            default:
                                throw new BiometricClassException("CaptureFaceCam  default. Status: " + status, BiometricExceptions.UNKNOWN);
                        }
                    }


                    _biometricClient.FaceCaptureDevice.Dispose();
                    face.Dispose();
                    subject.Dispose();
                    _biometricClient.Dispose();
                    Log.Print(@"------Fin Captura {0}", DateTime.Now.ToString());
                    return FaceData;
                }
            }
            catch (Neurotec.NeurotecException ex)
            {
                Log.Print("CaptureFaceCam error: " + ex.ToString());
                throw (ex);
            }
            catch (BiometricClassException ex)
            {
                throw (ex);
            }
            catch (Exception ex)
            {
                Log.Print("CaptureFaceCam error: " + ex.ToString());
                throw (ex);
            }
        }

        #endregion

        /// <summary>
        /// Realiza la extracción del rostro de una imagen y realia las validaciones de ojos, lentes, boca y umbrales.
        /// </summary>
        /// <returns> Datos del biométrico del rostro. </returns>
        public DataFace IdentifyFace(DataFace photo, bool DetectErrors)
        {
            DataFace FaceData = photo;
            FaceData.Model = "Genérico";
            FaceData.Serial = "0";
            FaceData.Manufacturer = "Genérico";
            FaceData.Status = null;
            byte[] PhotoFace = FaceData.FaceImage;
            NImage Photo = NImage.FromMemory(PhotoFace);
            try
            {

                using (var biometricClient = new NBiometricClient())
                using (var subject = new NSubject())
                using (var face = new NFace())
                {
                    //Face image will be read from file
                    face.Image = Photo;
                    subject.Faces.Add(face);

                    //bool isAdditionalComponentActivated = NLicense.IsComponentActivated("Biometrics.FaceExtraction,Biometrics.FaceMatching,Devices.Cameras,Biometrics.FaceSegmentsDetection");
                    bool isAdditionalComponentActivated = true;
                    if (isAdditionalComponentActivated)
                    {
                        // Set which features should be detected
                        //biometricClient.FacesDetectBaseFeaturePoints = true;
                        biometricClient.FacesDetectAllFeaturePoints = true;
                        //biometricClient.FacesRecognizeExpression = true;
                        biometricClient.FacesDetectProperties = true;
                    }
                    biometricClient.FacesCheckIcaoCompliance = true;
                    biometricClient.FacesQualityThreshold = 15;
                    biometricClient.FacesTokenImageWidth = 300;
                    var task = biometricClient.CreateTask(NBiometricOperations.DetectSegments | NBiometricOperations.Segment | NBiometricOperations.AssessQuality, subject);

                    //Perform task
                    biometricClient.PerformTask(task);

                    NBiometricStatus status = task.Status;
                    if (status == NBiometricStatus.Ok)
                    {
                        foreach (var attributes in face.Objects)
                        {

                            if (isAdditionalComponentActivated)
                            {
                                double avgFeature = 0;
                                bool blink = false;
                                bool mouthOpen = false;
                                bool darkGlasses = false;
                                bool hat = false;
                                bool glasses = false;
                                string message = string.Empty;
                                foreach (var featurePoint in attributes.FeaturePoints)
                                {
                                    avgFeature += int.Parse(featurePoint.Confidence.ToString());
                                }
                                
                                avgFeature = (avgFeature / attributes.FeaturePoints.Count);

                                //if (attributes.BlinkConfidence == 255)
                                //{
                                //    blink = true;
                                //    Log.Print("\t\tBlink detected");
                                //    message += "Blink detected ";
                                //}
                                //else
                                //{
                                //    blink = (attributes.Properties & NLProperties.Blink) == NLProperties.Blink;
                                //    Log.Print("\t\tBlink: {0}, Confidence: {1}", blink, attributes.BlinkConfidence);
                                //    if (blink)
                                //        message += "Blink detected ";
                                //    else
                                //        Log.Print("\t\tBlink not detected");
                                //}
                                //if (attributes.MouthOpenConfidence == 255)
                                //{
                                //    mouthOpen = true;
                                //    Log.Print("\t\tMouth open detected");
                                //    message += ", Mouth open detected ";
                                //}
                                //else
                                //{
                                //    mouthOpen = (attributes.Properties & NLProperties.MouthOpen) == NLProperties.MouthOpen;
                                //    Log.Print("\t\tMouth open: {0}, Confidence: {1}", mouthOpen, attributes.MouthOpenConfidence);
                                //    if (mouthOpen)
                                //        message += ", Mouth open detected ";
                                //    else
                                //        Log.Print("\t\tMouth open not detected");
                                //}

                                //if (attributes.DarkGlassesConfidence == 255)
                                //{
                                //    darkGlasses = true;
                                //    Log.Print("\t\tDark glasses detected");
                                //    message += ", Dark glasses detected ";
                                //}
                                //else
                                //{
                                //    darkGlasses = (attributes.Properties & NLProperties.DarkGlasses) == NLProperties.DarkGlasses;
                                //    Log.Print("\t\tDark glasses: {0}, Confidence: {1}", darkGlasses, attributes.DarkGlassesConfidence);
                                //    if (darkGlasses)
                                //        message += ", Dark glasses detected ";
                                //    else
                                //        Log.Print("\t\tDark glasses not detected");
                                //}
                                //if (attributes.HatConfidence == 255)
                                //{
                                //    hat = true;
                                //    Log.Print("\t\tHat detected");
                                //    message += ", Hat detected ";
                                //}
                                //else
                                //{
                                //    hat = (attributes.Properties & NLProperties.Hat) == NLProperties.Hat;
                                //    Log.Print("\t\tHat: {0}, Confidence: {1}", hat, attributes.HatConfidence);
                                //    if (hat)
                                //        message += ", Hat detected ";
                                //    else
                                //        Log.Print("\t\tHat not detected");
                                //}
                                //if (attributes.GlassesConfidence == 255)
                                //{
                                //    glasses = true;
                                //    Log.Print("\t\tGlasses detected");
                                //    message += ", Glasses detected ";
                                //}
                                //else
                                //{
                                //    glasses = (attributes.Properties & NLProperties.Glasses) == NLProperties.Glasses;
                                //    Log.Print("\t\tGlasses: {0}, Confidence: {1}", glasses, attributes.GlassesConfidence);
                                //    if (glasses)
                                //        message += ", Glasses detected ";
                                //    else
                                //        Log.Print("\t\tGlasses not detected");
                                //}

                                if ((blink || mouthOpen || darkGlasses || glasses) && DetectErrors)
                                //if ((blink) && DetectErrors)
                                {
                                    Log.Print(message);
                                    if (blink)
                                        throw new BiometricClassException("IdentifyFace Blink. Status : " + message, BiometricExceptions.Blink);
                                    else if (mouthOpen)
                                        throw new BiometricClassException("IdentifyFace mouthOpen.  Status: " + message, BiometricExceptions.MouthOpen);
                                    else if (darkGlasses)
                                        throw new BiometricClassException("IdentifyFace darkGlasses. Status : " + message, BiometricExceptions.FeatureDetected);
                                    else if (hat)
                                        throw new BiometricClassException("IdentifyFace Hat. Status : " + message, BiometricExceptions.FeatureDetected);
                                    else if (glasses)
                                        throw new BiometricClassException("IdentifyFace Glasses. Status : " + message, BiometricExceptions.FeatureDetected);
                                }
                                else
                                {
                                    Log.Print("OK , Confiabilidad: " + avgFeature);
                                    using (var image = subject.Faces[1].Image)
                                    {
                                        //BiometricNImages.Add(image);
                                        FaceData.FaceImage = getRecordFromImg(image, NImageFormat.Jpeg);
                                        FaceData.Hash = SHA256HexHashString(FaceData.FaceImage).ToUpper();
                                        Log.Print("image saved successfully");
                                    }
                                    FaceData.Status = "OK";

                                    return FaceData;
                                }
                            }
                        }
                    }
                    else
                    {
                        Log.Print("Status = {0}", status);
                        switch (status)
                        {
                            case NBiometricStatus.BadSharpness:
                            case NBiometricStatus.BadExposure:
                                throw new BiometricClassException("IdentifyFace BadSharpness. Status : " + status, BiometricExceptions.BadSharpness);
                            default:
                                throw new BiometricClassException("IdentifyFace  default. Status: " + status, BiometricExceptions.UNKNOWN);
                        }
                    }
                }
                //NLicense.ReleaseComponents(Components);
                //License.Release();

                return FaceData;
            }
            catch (Exception ex)
            {
                //NLicense.ReleaseComponents(Components);
                //License.Release();

                throw (ex);
            }
        }

        /// <summary>
        /// Realiza la coparación entre dos rostros.
        /// </summary>
        /// <returns></returns>
        public int FaceCompare(string photo, string photoDocument)
        {
            int result = 0;
            try
            {
                NImage Photo = NImage.FromMemory(Convert.FromBase64String(photo));
                NImage Photo2 = NImage.FromMemory(Convert.FromBase64String(photoDocument));

                // Obtain license
                //License.Get(Components);

                using (var biometricClient = new NBiometricClient())
                // Create subjects with face object
                using (NSubject referenceSubject = new NSubject())
                using (NSubject candidateSubject = new NSubject())
                using (var face = new NFace())
                using (var face2 = new NFace())
                {
                    face.Image = Photo;
                    face2.Image = Photo2;
                    referenceSubject.Faces.Add(face);
                    candidateSubject.Faces.Add(face2);
                    // Set matching threshold
                    biometricClient.FacesQualityThreshold = 15;
                    biometricClient.MatchingThreshold = 20;

                    // Set matching speed
                    biometricClient.FacesMatchingSpeed = NMatchingSpeed.Low;

                    // Verify subjects
                    NBiometricStatus status = biometricClient.Verify(referenceSubject, candidateSubject);
                    if (status == NBiometricStatus.Ok || status == NBiometricStatus.MatchNotFound)
                    {
                        int score = referenceSubject.MatchingResults[0].Score;
                        result = score;
                        LogCmd.Log(string.Format("image scored {0}, verification status:{1}", score, status == NBiometricStatus.Ok ? "succeeded" : "failed"));
                    }
                    else
                    {
                        Console.Write("Verification failed. Status: {0}", status);
                    }
                }

            }
            catch (Exception ex)
            {
                Console.Write("Verification failed, error: {0}", ex.Message);
            }
            //License.Release();
            return result;
        }

        /// <summary>
        /// Identifica el número de posiciones que soporta el lector.
        /// </summary>
        /// <param name="DeviceType">Tipo de lector</param>
        /// <returns>Número de posiciones</returns>
        public int GetSupportedPositions(int DeviceType)
        {

            int Positions = 0;
            var biometricClient = new NBiometricClient();
            try
            {
                biometricClient.UseDeviceManager = true;
                biometricClient = GetDevice((NDeviceType)DeviceType, biometricClient);
                Positions = biometricClient.FingerScanner.GetSupportedPositions().Length;
                return Positions;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                biometricClient.FingerScanner.Dispose();
                biometricClient.DeviceManager.Dispose();
                biometricClient.Dispose();
            }
        }

        /// <summary>
        /// Se intenta crear el template de la imagen de la huella para comprobar que puede ser utilizada después
        /// en la comparación.
        /// </summary>
        /// <param name="fingerCaptured">Imagen de la huella</param>
        /// <returns>Resultado de la creación del template</returns>
        public bool CrearTemplateHuella(byte[] fingerCaptured)
        {
            NImage ImageCaptured = NImage.FromMemory(fingerCaptured);
            try
            {
                using (var biometricClient = new NBiometricClient())
                using (NSubject referenceSubject = new NSubject())
                using (NSubject candidateSubject = new NSubject())
                using (var FingerCaptured = new NFinger())
                using (var FingerStored = new NFinger())
                {
                    FingerCaptured.Image = ImageCaptured;
                    referenceSubject.Fingers.Add(FingerCaptured);
                    biometricClient.CreateTemplate(referenceSubject);
                    if (referenceSubject.Status == NBiometricStatus.Ok)
                        return true;
                    else
                        return false;
                }
            }
            catch (Exception ex)
            {
                Log.LogError("Error en CrearTemplateHuella: " + ex.ToString());
                throw (ex);
            }

        }

        /// <summary>
        /// Verifica si ambas biometrias son iguales. 
        /// </summary>
        /// <param name="fingerCaptured">Biometría a comparar</param>
        /// <param name="fingerStored">Biometría previemente guardada</param>
        /// <returns>Resultado de la comparación</returns>
        public bool FingerCompare(byte[] fingerCaptured, byte[] fingerStored)
        {
            NImage ImageCaptured = NImage.FromMemory(fingerCaptured);
            NImage ImageStored = NImage.FromMemory(fingerStored);
            int matchScore = 0;
            try
            {
                using (var biometricClient = new NBiometricClient())
                using (NSubject referenceSubject = new NSubject())
                using (NSubject candidateSubject = new NSubject())
                using (var FingerCaptured = new NFinger())
                using (var FingerStored = new NFinger())
                {
                    FingerCaptured.Image = ImageCaptured;
                    FingerStored.Image = ImageStored;
                    referenceSubject.Fingers.Add(FingerCaptured);
                    candidateSubject.Fingers.Add(FingerStored);
                    // Set matching threshold
                    biometricClient.MatchingThreshold = 48;
                    biometricClient.CreateTemplate(referenceSubject);
                    biometricClient.CreateTemplate(candidateSubject);
                    // Verify subjects
                    biometricClient.MatchingWithDetails = true;
                    NBiometricStatus status = biometricClient.Verify(referenceSubject, candidateSubject);
                    //  var attributes = referenceSubject.fingers[0].Objects[0].Template;
                    if (status == NBiometricStatus.Ok || status == NBiometricStatus.MatchNotFound)
                    {
                        matchScore = referenceSubject.MatchingResults[0].Score;
                        Log.Print("image scored {0}, verification.. ", matchScore);
                        Log.Print(status == NBiometricStatus.Ok ? "succeeded " : "failed " + System.DateTime.Now);
                        return status == NBiometricStatus.Ok ? true : false;
                    }
                    else
                    {
                        Log.LogError("Fallo la busqueda de duplicados. status: " + status.ToString());

                        throw new Exception("Fallo la busqueda de duplicados. status: " + status.ToString());
                    }

                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public bool FingerCompareTemplate(byte[] fingerCaptured, byte[] fingerStored)
        {
            var fingerCapBuffer = new NBuffer(fingerCaptured);
            var fingerStoBuffer = new NBuffer(fingerStored);



            int matchScore = 0;
            bool founded = false;
            try
            {
                using (var biometricClient = new NBiometricClient())
                using (NSubject referenceSubject = new NSubject())
                using (NSubject candidateSubject = new NSubject())
                {

                    //referenceSubject.SetTemplate(fingerCapturedT);
                    //candidateSubject.SetTemplate(fingerStoredT);



                    referenceSubject.SetTemplateBuffer(fingerCapBuffer);
                    candidateSubject.SetTemplateBuffer(fingerStoBuffer);


                    // Set matching threshold

                    biometricClient.MatchingThreshold = 48;

                    // Verify subjects
                    biometricClient.MatchingWithDetails = false;

                    biometricClient.BiometricTypes = NBiometricType.Fingerprint;

                    biometricClient.FingersMatchingSpeed = NMatchingSpeed.Low;

                    //biometricClient.MatchingFirstResultOnly

                    //biometricClient.LocalOperations = NBiometricOperations.VerifyOffline;

                    //var status3 = biometricClient.CreateTask(NBiometricOperations.Verify, referenceSubject, candidateSubject);



                    NBiometricStatus status = biometricClient.Verify(referenceSubject, candidateSubject);

                    if (status == NBiometricStatus.Ok || status == NBiometricStatus.MatchNotFound)
                    {
                        matchScore = referenceSubject.MatchingResults[0].Score;
                        //Console.Write("image scored {0}, verification.. ", matchScore);
                        Log.Print("Image scored {0}, verification.. {1}", matchScore, status == NBiometricStatus.Ok ? "succeeded" : "failed");
                        founded = status == NBiometricStatus.Ok ? true : false;
                    }
                    else
                    {
                        founded = false;
                        throw new Exception("Fallo la busqueda de duplicados. status: " + status.ToString());
                    }

                    return founded;
                }

            }
            catch (Exception ex)
            {
                throw (ex);
                return founded;
            }
        }

        /// <summary>
        /// Crea el NIST en sus dos formatos .nist y .xml
        /// </summary>
        /// <param name="Fingers">Lista de huellas</param>
        /// <param name="Absences">Lista de ausencias</param>
        /// <param name="Faces">Rostro</param>
        /// <param name="File">URL donde guardara el NIST</param>
        /// <param name="userFullname">Nombre (Datos biográficos son sustituidos después para la personalización del NIST para Santander) </param>
        /// <param name="birthCountry">País de nacimiento (Datos biográficos son sustituidos después para la personalización del NIST para Santander)</param>
        /// <param name="birthDate">Fecha de nacimiento (Datos biográficos son sustituidos después para la personalización del NIST para Santander)</param>
        /// <param name="gender">Sexo (Datos biográficos son sustituidos después para la personalización del NIST para Santander)</param>
        /// <param name="service">Tipo de servicio (Enrolamiento, verificación, etc.) #YA NO SE OCUPA la personalización del NIST para Santander se realiza en PROCESS#</param>
        public void CreateNImagesForNIST(List<DataFinger> Fingers, List<DataAbsence> Absences, DataFace Faces, string File, string userFullname, string birthCountry, string birthDate, string gender, string service)
        {
            //Varios de los datos que se envían solo son para que pueda generar el NIST básico, en el process se modifican varios de ellos
            //"BSM" : Banco Santander México
            //"Clave de la Sucursal" : #Se sustituira más adelante#
            //"LFIS" :  Live Face Identification System
            CreateNIST(File, "LFIS", "BSM", "Clave de la Sucursal", "1", "Clave de la Sucursal", "1", service, Absences, Fingers, Faces, userFullname, birthCountry, birthDate, "Male");
            CreateNIST(File, "LFIS", "BSM", "Clave de la Sucursal", "1", "Clave de la Sucursal", "0", service, Absences, Fingers, Faces, userFullname, birthCountry, birthDate, "Male");
        }

        /// <summary>
        /// Revisa si hay algun dispositivo del tipo especificado conectado.
        /// </summary>
        /// <param name="DeviceType">Tipo de dispositivo.</param>
        /// <returns></returns>
        public bool IsDeviceConected(int DeviceType, bool isKojakWatson)
        {
            var dispositivoEncontrado = false;
            var biometricClient = new NBiometricClient();
            try
            {
                var fingerScannerRegex = isKojakWatson ? @"KOJAK|WATSON" : @"U\.are\.U|COLUMBO";
                biometricClient.UseDeviceManager = true;
                biometricClient = GetDevice((NDeviceType)DeviceType, biometricClient, (NDeviceType)DeviceType == NDeviceType.FingerScanner ? fingerScannerRegex : null);
                switch ((NDeviceType)DeviceType)
                {
                    case NDeviceType.FingerScanner:
                        dispositivoEncontrado = biometricClient.FingerScanner != null && Regex.IsMatch(biometricClient.FingerScanner.DisplayName, fingerScannerRegex, RegexOptions.IgnoreCase);
                        if (dispositivoEncontrado)
                            Log.Print(">>Device to use ->" + biometricClient.FingerScanner.DisplayName + "-" + biometricClient.FingerScanner.Model);
                        break;
                    case NDeviceType.IrisScanner:
                        dispositivoEncontrado = biometricClient.IrisScanner != null;
                        if (dispositivoEncontrado)
                            Log.Print(">>Device to use ->" + biometricClient.IrisScanner.DisplayName + "-" + biometricClient.IrisScanner.Model);
                        break;
                    case NDeviceType.Camera:
                        dispositivoEncontrado = biometricClient.FaceCaptureDevice != null;
                        if (dispositivoEncontrado)
                            Log.Print(">>Device to use ->" + biometricClient.FaceCaptureDevice.DisplayName + "-" + biometricClient.FaceCaptureDevice.Model);
                        break;
                }
                return dispositivoEncontrado;
            }
            catch (BiometricClassException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                biometricClient.DeviceManager.Dispose();
                biometricClient.Dispose();
            }
        }

        public byte[] getWSQArray(byte[] imgbmp)
        {
            try
            {
                NImage imagebmp = NImage.FromMemory(imgbmp);
                return getRecordFromImg(imagebmp, NImageFormat.Wsq);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        #endregion

        #region Private

        #region NIST

        /// <summary>
        /// Crea el objeto ANTemplate y le va agregando los registros necesarios para crear el NIST para al final guardarlo localmente
        /// </summary>
        /// <param name="nameFile">Name of file to generate(ej. "MyNistfile" ) whitout extension, it will be defined by the encod , when encod = 1 -.xml else  -.nist</param>
        /// <param name="tot">type of transaction</param>
        /// <param name="dai">destination agency identifier</param>
        /// <param name="ori">originating agency identifier</param>
        /// <param name="tcn"> transaction control number</param>
        /// <param name="src"> Source Agency Name</param>
        /// <param name="encod">encoding type ony values "0" or "1"  1: .xml 0: .nist</param>
        /// <param name="service">
        /// 3000-3999.- Enrolamiento
        /// 4000-4999.- Verificación
        /// </param>
        /// <param name="Allfingerimages">List of finger images to add to the nistFile, if you don't use it set null value</param>
        /// <param name="faceImage">List of face image to add to the nistFile, if you don't use set it null value</param>
        /// <param name="sigantureImage">List of signature image to add to the nistFile, if you don't use it set null value</param>
        /// <param name="AllIrisesImages">List of Iris image to add to the nistFile, if you don't use it set null value</param>
        public void CreateNIST(string nameFile, string tot, string dai, string ori, string tcn, string src, string encod, string service, List<DataAbsence> Allabsences = null, List<DataFinger> Allfingerimages = null, DataFace AllfaceImages = null, string userFullName = null, string birthCountry = null, string birthDate = null, string gender = null, List<Bitmap> AllsigantureImages = null, List<Bitmap> AllIrisesImages = null)
        {
            int idc = 0;
            BdifEncodingType encoding = (encod == "1") ? BdifEncodingType.Xml : BdifEncodingType.Traditional;
            if (encoding == BdifEncodingType.Xml)
                nameFile = nameFile + ".xml";
            else
                nameFile = nameFile + ".nist";
            // Create empty ANTemplate object with only type 1 record in it
            using (ANTemplate template = new ANTemplate(ANTemplate.VersionCurrent, tot, dai, ori, tcn, 0))
            {
                if (!(string.IsNullOrEmpty(userFullName) || string.IsNullOrEmpty(birthCountry) || string.IsNullOrEmpty(birthDate) || string.IsNullOrEmpty(gender)))
                {
                    var record = ANTemplateGetRecordType2Biographic(template, idc, encoding, userFullName, birthCountry, birthDate, gender);
                    //template.Records.Add(record);
                    idc++;
                }
                var record2 = ANTemplateGetRecordType2Biographic(template, idc, BdifEncodingType.Xml, "alskdh", "MSDIFNOSD", "27041994", "Male");
                //template.Records.Add(record2);

                idc++;
                if (AllfaceImages != null)
                {
                    //foreach (Bitmap btmfaceImage in AllfaceImages)

                    //// Create Type 10 record
                    var record = ANTemplateGetRecordType10Face(template, idc, AllfaceImages.FaceImage, src);
                    // Add Type 10 record to ANTemplate object
                    // image type contained in file, surely face
                    //template.Records.Add(record);

                    idc++;

                }
                if (Allabsences != null)
                {
                    if (Allabsences.Count > 0)
                    {
                        foreach (DataAbsence Absence in Allabsences)
                        {
                            // Create Type 14 record
                            //var record = new ANType14Record(idc);

                            ANType14Record record = template.Records.AddType14();
                            record.Idc = idc;


                            if (Absence.AbsenceCause == "AMPUTATED") //Se revisa si fue ausencia por amputación o por mala calidad
                            {
                                record.Amputations.Add(new ANFAmputation((BdifFPPosition)Absence.Position, ANFAmputationType.Amputation));
                            }
                            else
                                record.Amputations.Add(new ANFAmputation((BdifFPPosition)Absence.Position, ANFAmputationType.UnableToPrint));

                            record.SourceAgency = ori;
                            record.Positions.Add((BdifFPPosition)Absence.Position);
                            //template.Records.Add(record);
                            idc++;

                        }
                    }
                }
                if (Allfingerimages != null)
                {
                    if (Allfingerimages.Count > 0)
                    {

                        //foreach (Bitmap btmimgFinger in Allfingerimages)
                        foreach (DataFinger btmimgFinger in Allfingerimages)
                        {


                            // Create Type 14 record
                            using (var ms = new MemoryStream(btmimgFinger.BMP))
                            {
                                Bitmap bmp = new Bitmap(ms);
                                btmimgFinger.Hash = SHA256HexHashString(btmimgFinger.BMP).ToUpper();
                                NImage imgFinger = NImage.FromBitmap(bmp);
                                ANType14Record record = ANTemplateGetRecordType14Finger(template, idc, imgFinger, src);
                                // Add Type 14 record to ANTemplate object
                                record.SetMakeModelSerialNumber(btmimgFinger.Manufacturer, btmimgFinger.Model, btmimgFinger.Serial);
                                record.Positions.Add((BdifFPPosition)btmimgFinger.Position);
                                //template.Records.Add(record);
                                idc++;
                            }

                        }
                    }
                }
                if (AllsigantureImages != null)
                {
                    if (AllsigantureImages.Count > 0)
                    {
                        foreach (Bitmap sigantureImage in AllsigantureImages)
                        {
                            using (NImage lrBinImage = NImage.FromBitmap(sigantureImage))
                            {

                                lrBinImage.HorzResolution = 500;
                                lrBinImage.VertResolution = 500;
                                lrBinImage.ResolutionIsAspectRatio = false;

                                // Create Type 8 record
                                var record = ANTemplateGetRecordType8Signature(template, idc, lrBinImage);
                                //record.CaptureOrganizationName = orn;
                                // Add Type 8 record to ANTemplate object
                                template.Records.Add(record);
                                idc++;
                            }
                        }
                    }
                }
                if (AllIrisesImages != null)
                {
                    if (AllIrisesImages.Count > 0)
                    {
                        foreach (Bitmap btmirisImage in AllIrisesImages)
                        {
                            using (NImage lrBinImage = NImage.FromBitmap(btmirisImage))
                            {

                                // Create Type 17 record
                                var record = ANTemplateGetRecordType17Iris(template, idc, lrBinImage, src);
                                // Add Type 17 record to ANTemplate object
                                template.Records.Add(record);
                                idc++;
                            }
                        }
                    }
                }


                if (File.Exists(nameFile))
                {
                    File.Delete(nameFile);
                }
                template.Save(nameFile, encoding);
                Log.Print("NIST CREADO");
            }
        }

        /// <summary>
        /// Regresa un registro Forma-10 para biométricos de rostro.
        /// </summary>
        /// <param name="idc">Image designation character value (Indica el número de registro dentro de todo el paquete NIST)</param>
        /// <param name="faceImage">Imagen del rostro</param>
        /// <param name="src">Identification of organization</param>
        /// <returns>Template 10</returns>
        private static ANType10Record ANTemplateGetRecordType10Face(ANTemplate template, int idc, byte[] faceImage, string src)
        {
            ANImageType imt = ANImageType.Face;
            ANImageCompressionAlgorithm cga = ANImageCompressionAlgorithm.None;
            BdifScaleUnits slc = BdifScaleUnits.None;
            //ANType10Record record;

            try
            {
                //using (NImage rgbImage = faceImage)
                //{
                //    record = new ANType10Record();
                //    record = new ANType10Record(ANTemplate.VersionCurrent, idc, imt, src, slc, cga, null, rgbImage);
                //    return record;
                //}
                using (var ms = new MemoryStream(faceImage))
                using (NImage image = NImage.FromBitmap(new Bitmap(ms)))
                using (NImage rgbImage = NImage.FromImage(NPixelFormat.Rgb8U, 0, image))
                {
                    rgbImage.ResolutionIsAspectRatio = true;

                    // Create Type 10 record
                    //var record = new ANType10Record(ANTemplate.VersionCurrent, idc, imt, src, slc, cga, null, rgbImage);

                    ANType10Record record = template.Records.AddType10(ANImageType.Face, src, rgbImage.Save());
                    record.Idc = idc;


                    // Sets additional optional fields for face modality
                    ANDistortion distortion = new ANDistortion(ANDistortionCode.Barrel, ANDistortionMeasurementCode.Estimated, ANDistortionSeverityCode.Mild);
                    record.Distortion = distortion;
                    record.LightingArtifacts.Add(ANLightingArtifact.FaceShadows);
                    record.SubjectPose = ANSubjectPose.FullFaceFrontal;
                    record.TieredMarkupCollection = ANTieredMarkupCollection.EyeCenters;
                    record.ImageTransformation = (BdifFacePostAcquisitionProcessing)(BdifFacePostAcquisitionProcessing.PoseCorrected | BdifFacePostAcquisitionProcessing.ContrastStretched);

                    // Add Type 10 record to ANTemplate object
                    // image type contained in file, surely face
                    return record;

                }

            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        /// <summary>
        /// Regresa un registro Forma-17 para biométricos de iris.
        /// </summary>
        /// <param name="idc">Image designation character value (Indica el número de registro dentro de todo el paquete NIST)</param>
        /// <param name="irisImage">Imagen del iris</param>
        /// <param name="src">Identification of organization</param>
        /// <returns>Template 17</returns>
        private static ANType17Record ANTemplateGetRecordType17Iris(ANTemplate template, int idc, NImage irisImage, string src)
        {
            ANImageCompressionAlgorithm cga = ANImageCompressionAlgorithm.None;
            BdifScaleUnits slc = BdifScaleUnits.None;
            ANType17Record record;


            using (NImage image = irisImage)
            {
                image.ResolutionIsAspectRatio = true;
                using (NImage rgbImage = NImage.FromImage(NPixelFormat.Rgb8U, 0, image))
                {
                    //record = new ANType17Record(ANTemplate.VersionCurrent, idc, src, slc, cga, rgbImage);

                    record = template.Records.AddType17(src, rgbImage.Save());
                    record.Idc = idc;

                    return record;
                }
            }

        }
        /// <summary>
        /// Regresa un registro Forma-14 para biométricos de huellas dactilares.
        /// </summary>
        /// <param name="idc">Image designation character value (Indica el número de registro dentro de todo el paquete NIST)</param>
        /// <param name="fingerImage">Imagen de la huella dactilar</param>
        /// <param name="src">Identification of organization</param>
        /// <returns>Template 14</returns>
        private static ANType14Record ANTemplateGetRecordType14Finger(ANTemplate template, int idc, NImage fingerImage, string src)
        {
            ANImageCompressionAlgorithm cga = ANImageCompressionAlgorithm.Wsq20;
            BdifScaleUnits slc = BdifScaleUnits.PixelsPerInch;
            ANType14Record record;

            using (NImage image = NImage.FromBitmap(fingerImage.ToBitmap()))
            // Convert to grayscale image
            using (NImage hrGrayImage = NImage.FromImage(NPixelFormat.Grayscale8U, 0, image))
            {
                hrGrayImage.HorzResolution = 500;
                hrGrayImage.VertResolution = 500;
                hrGrayImage.ResolutionIsAspectRatio = false;

                // Create Type 14 record
                //record = new ANType14Record(ANTemplate.VersionCurrent, idc, src, slc, cga, hrGrayImage);
                record = template.Records.AddType14(src, hrGrayImage.Save());
                return record;
            }




        }
        /// <summary>
        /// Regresa un registro Forma-4 para biométricos de huellas dactilares.
        /// </summary>
        /// <param name="idc">Image designation character value (Indica el número de registro dentro de todo el paquete NIST)</param>
        /// <param name="fingerImage">Imagen de la huella dactilar</param>
        /// <returns>Template 4</returns>
        private static ANType4Record ANTemplateGetRecordType4Finger(ANTemplate template, int idc, NImage fingerImage)
        {
            using (NImage image = fingerImage)
            {
                if (image.VertResolution < 250)
                {
                    Log.Print("vertical resolution is less than 250 (resolution {0}), forcing 500 resolution.", image.VertResolution);
                    image.VertResolution = 500;
                }
                if (image.HorzResolution < 250)
                {
                    Log.Print("horizontal resolution is less than 250 (resolution {0}), forcing 500 resolution.", image.HorzResolution);
                    image.HorzResolution = 500;
                }
                image.ResolutionIsAspectRatio = false;

                // Create Type 4 record
                //var record = new ANType4Record(ANTemplate.VersionCurrent, idc, true, ANImageCompressionAlgorithm.Wsq20, image);

                var record = template.Records.AddType4(true, ANImageCompressionAlgorithm.Wsq20, image);
                record.Idc = idc;

                // Add Type 4 record to ANTemplate object
                return record;

            }
        }
        /// <summary>
        /// Regresa un registro Forma-8 para biométricos de firmas.
        /// </summary>
        /// <param name="idc">Image designation character value (Indica el número de registro dentro de todo el paquete NIST)</param>
        /// <param name="signatureImage">Imagen de la firma</param>
        /// <returns>Template 8</returns>
        private static ANType8Record ANTemplateGetRecordType8Signature(ANTemplate template, int idc, NImage signatureImage)
        {
            using (NImage lrBinImage = signatureImage)
            {
                lrBinImage.HorzResolution = 500;
                lrBinImage.VertResolution = 500;
                lrBinImage.ResolutionIsAspectRatio = false;

                // Create Type 8 record
                //var record = new ANType8Record(ANTemplate.VersionCurrent, idc, ANSignatureType.Official, ANSignatureRepresentationType.ScannedUncompressed, true, lrBinImage);

                var record = template.Records.AddType8(ANSignatureType.Official, ANSignatureRepresentationType.ScannedUncompressed, true, lrBinImage);
                record.Idc = idc;
                // Add Type 8 record to ANTemplate object
                return record;

            }
        }
        /// <summary>
        /// Regresa un registro Forma-2 para datos biográficos.
        /// </summary>
        /// <param name="idc">Image designation character value (Indica el número de registro dentro de todo el paquete NIST)</param>
        /// <param name="encoding">NO SE DEBERÍA USAR</param>
        /// <param name="userFullName">Nombre completo</param>
        /// <param name="birthCountry">UK, MX , US, etc...</param>
        /// <param name="birthDate">"19700131" formato aaaammdd</param>
        /// <param name="gender">M- Male, F-Female</param>
        /// <returns>Template 2</returns>
        private static ANType2Record ANTemplateGetRecordType2Biographic(ANTemplate template, int idc, BdifEncodingType encoding, string userFullName, string birthCountry, string birthDate, string gender)
        {
            int nameFieldNumber = 18;
            int placeOfBirthFieldNumber = 20;
            int dateOfBirthFieldNumber = 22;
            int genderFieldNumber = 24;
            ANType2Record record;

            //record = new ANType2Record(ANTemplate.VersionCurrent, idc, 0);
            record = template.Records.AddType2();
            record.Idc = idc;

            if (encoding == BdifEncodingType.Traditional)
            {
                record.Fields.Add(nameFieldNumber, "name, " + userFullName);
                record.Fields.Add(placeOfBirthFieldNumber, birthCountry);
                record.Fields.Add(dateOfBirthFieldNumber, birthDate);
                record.Fields.Add(genderFieldNumber, gender);
            }
            else
            {
                record.Fields.Add(nameFieldNumber, "PersonName", "name, " + userFullName);
                record.Fields.Add(placeOfBirthFieldNumber, "PersonBirthPlaceCode", birthCountry);
                record.Fields.Add(dateOfBirthFieldNumber, "PersonBirthDate", birthDate);
                record.Fields.Add(genderFieldNumber, "PersonSexCode", gender);
            }
            return record;

        }
        #endregion

        #region Device Functions
        /// <summary>
        /// Realiza la busqueda del dispositivo dependiendo del tipo.
        /// </summary>
        /// <param name="DeviceType">Tipo de dispositivo</param>
        /// <param name="BiometricClient">Objeto al que se le asigna el dispositivo para su uso</param>
        /// <returns>Biometric client con el dispositivo asignado</returns>
        private NBiometricClient GetDevice(NDeviceType DeviceType, NBiometricClient BiometricClient, string regexDevice = null)
        {
            NDeviceManager DeviceManager = BiometricClient.DeviceManager;
            try
            {
                DeviceManager.DeviceTypes = DeviceType;
                DeviceManager.Initialize();
                switch (DeviceType)
                {
                    case NDeviceType.FingerScanner:
                        BiometricClient.FingerScanner = (NFingerScanner)SearchDevice((NFingerScanner)null, DeviceManager, regexDevice);
                        break;
                    case NDeviceType.IrisScanner:
                        BiometricClient.IrisScanner = (NIrisScanner)SearchDevice((NIrisScanner)null, DeviceManager);
                        break;
                    case NDeviceType.Camera:
                        BiometricClient.FaceCaptureDevice = (NCamera)SearchDevice((NCamera)null, DeviceManager);
                        break;
                }

                return BiometricClient;

            }
            catch (BiometricClassException ex)
            {
                DeviceManager.Dispose();
                Log.Print("!!Error on GetDevice: " + ex.Message.ToString());
                ex.InnerMessage = "GetDevice. No se detectaron dispositivos tipo: " + DeviceType;
                throw (ex);
            }

        }
        /// <summary>
        /// Realiza la busqueda del tipo de dispositivo especificado
        /// </summary>
        /// <param name="CurrentDevice">Objeto del tipo de dispositivo</param>
        /// <param name="DeviceManager">Objeto de neuro para administrar dispositivos</param>
        /// <returns>Objeto del dispositivo listo para usar</returns>
        private NBiometricDevice SearchDevice(NBiometricDevice CurrentDevice, NDeviceManager DeviceManager, string regexDevice = null)
        {
            try
            {
                if (DeviceManager.Devices.Count > 0)
                {
                    var deviceList = DeviceManager.Devices.Where(item => item is NBiometricDevice || typeof(NBiometricDevice).IsAssignableFrom(CurrentDevice.GetType())).Cast<NBiometricDevice>().ToList();
                    if (deviceList?.Any() ?? false)
                    {
                        Log.Print($">>SearchDevice -> Se detectaron {deviceList.Count} lectores");
                        if (!string.IsNullOrEmpty(regexDevice))
                        {
                            var devices = deviceList.LastOrDefault(item => Regex.IsMatch(item.DisplayName, regexDevice, RegexOptions.IgnoreCase));
                            if (devices != null)
                                return devices;
                        }
                        else
                            return deviceList.LastOrDefault();
                    }
                    Log.Print(">>SearchDevice -> No se detectaron lectores del tipo especificado dentro de los que se encontraron.");
                    throw new BiometricClassException("", BiometricExceptions.NoDevice);
                }
                else
                {
                    Log.Print(">>SearchDevice -> No se detectaron lectores.");
                    throw (new BiometricClassException("", BiometricExceptions.NoDevice));
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// Realiza la busqueda del tipo de dispositivo especificado (Solo para cámara porque el tipo de dispositivo es distinto
        /// a el de iris y de huella)
        /// </summary>
        /// <param name="CurrentDevice">Objeto del tipo de dispositivo</param>
        /// <param name="DeviceManager">Objeto de neuro para administrar dispositivos</param>
        /// <returns>Objeto del dispositivo listo para usar</returns>
        private NCaptureDevice SearchDevice(NCaptureDevice CurrentDevice, NDeviceManager DeviceManager)
        {
            try
            {
                if (DeviceManager.Devices.Count > 0)
                {
                    Log.Print(">>Found : " + DeviceManager.Devices.Count + " devices.");
                    foreach (NDevice device in DeviceManager.Devices)
                    {
                        if (device.DisplayName.IndexOf("Logitech Webcam C930e") != -1 || _modoTestFace)
                        {
                            Log.Print("SE ENCONTRÓ  Logitech Webcam C930e");
                            CurrentDevice = (NCaptureDevice)device;
                        }
#if LOCAL
                        else if (device.DisplayName.Contains("Integrated Webcam"))
                        {
                            //Log("SE ENCONTRÓ  Integrated Webcam");
                            CurrentDevice = (NCaptureDevice)device;
                        }
#endif
                    }
                    if (CurrentDevice != null)
                    {
                        Log.Print(">>Device to use ->" + CurrentDevice.DisplayName + "-" + CurrentDevice.Model);
                        return CurrentDevice;
                    }
                    else
                    {
                        Log.Print(">>SearchDevice -> No se detectaron lectores.");
                        throw (new BiometricClassException("", BiometricExceptions.NoDevice));
                    }
                }
                else
                {
                    Log.Print(">>SearchDevice -> No se detectaron lectores.");
                    throw (new BiometricClassException("", BiometricExceptions.NoDevice));
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        #endregion

        #region Face Events

        private void face_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if ("Image".Equals(e.PropertyName))
            {
                //image changed, redraw it
            }

        }

        private void Objects_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Reset)
            {
                foreach (NLAttributes item in monitorredAtributes)
                {
                    item.PropertyChanged -= attributes_PropertyChanged;
                }
                monitorredAtributes.Clear();
            }
            else
            {
                if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add)
                {
                    foreach (var item in e.NewItems)
                    {
                        NLAttributes attributes = (NLAttributes)item;
                        monitorredAtributes.Add(attributes);
                        attributes.PropertyChanged += attributes_PropertyChanged;
                    }
                }
                else
                {
                    if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
                    {
                        foreach (var item in e.OldItems)
                        {
                            NLAttributes attributes = (NLAttributes)item;
                            monitorredAtributes.Remove(attributes);
                            attributes.PropertyChanged -= attributes_PropertyChanged;
                        }
                    }
                }
            }
            //repaint();

        }

        private void attributes_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            //Logger.Log(e.PropertyName);

            repaint();
            if ("LivenessAction".Equals(e.PropertyName))
            {
                Log.Print("attributes_PropertyChanged: " + monitorredAtributes[0].LivenessAction);
                #region Follow Target
                ////if (monitorredAtributes[0].LivenessAction.ToString().Contains("Blink"))
                ////    OnshowInstructions(new DisplayInstructionsEventArgs("0", "0", "Blink"));
                //if (!InstructionActual.Contains(monitorredAtributes[0].LivenessAction.ToString()))
                //{
                //    InstructionActual = monitorredAtributes[0].LivenessAction.ToString();

                //    OnshowInstructions(new DisplayInstructionsEventArgs("0", "0", InstructionActual));
                //    LogCmd.Log(">>>>------> Instruccion : " + monitorredAtributes[0].LivenessAction.ToString());
                //}
                #endregion
                #region Custom Liveness
                OnshowInstructions(new DisplayInstructionsEventArgs(monitorredAtributes[0].LivenessAction.ToString()));
                #endregion
            }
        }

        private void repaint()
        {
            //NLAttributes[] attributesArray = (NLAttributes[])face.Objects.ToArray();
            for (int i = 0; i < monitorredAtributes.Count; i++)
            {
                NLAttributes attributes = monitorredAtributes[i];
                var action = attributes.LivenessAction;
                byte score = attributes.LivenessScore;
                bool rotation = action.Equals(NLivenessAction.RotateYaw);
                bool blink = action.Equals(NLivenessAction.Blink);
                bool keepStill = action.Equals(NLivenessAction.KeepStill);

                if (rotation)
                {
                    float yaw = attributes.Yaw;
                    float targetYaw = attributes.LivenessTargetYaw;
                    #region Follow Target
                    //OnshowInstructions(new DisplayInstructionsEventArgs(yaw.ToString(), targetYaw.ToString(), action.ToString()));
                    #endregion
                    //WhereAmI(yaw, targetYaw);
                    if (targetYaw > yaw)
                    {
                        if (RotateDirection != 1)
                        {
                            LogCmd.Log("rotate right");
                            RotateDirection = 1;
                        }
                    }
                    if (yaw > targetYaw)
                    {
                        if (RotateDirection != 2)
                        {
                            LogCmd.Log("rotate left");
                            RotateDirection = 2;
                        }
                    }
                }
                else if (blink)
                {
                    float yaw = attributes.Yaw;
                    float targetYaw = attributes.LivenessTargetYaw;
                    #region Follow Target
                    //OnshowInstructions(new DisplayInstructionsEventArgs(yaw.ToString(), targetYaw.ToString(), action.ToString()));
                    #endregion
                    if (RotateDirection != 3)
                    {
                        LogCmd.Log("Blink");
                        RotateDirection = 3;
                    }
                }

                if (keepStill)
                {
                    if (RotateDirection != 4)
                    {
                        LogCmd.Log("Keep still " + score);
                        RotateDirection = 4;
                    }
                }


            }
        }

        public virtual void OnshowInstructions(DisplayInstructionsEventArgs e)
        {
            if (showInstructions != null)
                showInstructions(this, e);
        }
        #endregion

        #region Preview Functions
        /// <summary>
        /// Se recibe el frame de captura en vivo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NFScanner_Preview(object sender, NBiometricDeviceCapturePreviewEventArgs e)
        {
            NFrictionRidge Imagen = (NFrictionRidge)e.Biometric;
            if (Imagen.Image != null)
            {
                sampleImage = Imagen.Image.ToBitmap();
                OnshowPreview(new DisplayImageEventArgs(sampleImage));
            }
        }

        /// <summary>
        /// Se recibe el frame de captura en vivo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NIrisScanner_Preview(object sender, NBiometricDeviceCapturePreviewEventArgs e)
        {
            NIris Imagen = (NIris)e.Biometric;
            if (Imagen.Image != null)
            {
                sampleImage = Imagen.Image.ToBitmap();
                OnshowPreview(new DisplayImageEventArgs(sampleImage));
            }
        }

        private void NCamera_Preview(object sender, EventArgs e)
        {

            try
            {
                NImage Imagen;
                NBuffer imgBuff;
                byte[] ByteImg = null;
                while (_biometricClient.FaceCaptureDevice.IsCapturing)
                {
                    Thread.Sleep(100);
                    Imagen = _biometricClient.FaceCaptureDevice.GetFrame();
                    if (Imagen != null)
                    {
                        Imagen.FlipHorizontally();
                        imgBuff = Imagen.Save(NImageFormat.Bmp);
                    }
                    else
                        break;

                    ByteImg = imgBuff.ToArray();

                    #region IMAGE REDUCTION TEST
                    //using (MemoryStream memoryStream = new MemoryStream(ByteImg))
                    //{
                    //    Bitmap frontbit = new Bitmap(memoryStream);
                    //    ByteImg = BA.Biocheck.Core.Common.Util.ImageCustom.Resize2(frontbit,480,480, 100, 100);
                    //}
                    #endregion

                    imgBuff.Dispose();
                    Imagen.Dispose();
                    if (ByteImg != null)
                    {
                        OnshowPreview(new DisplayImageEventArgs(ByteImg));
                    }
                    ByteImg = null;
                }
            }
            catch (OutOfMemoryException ex)
            {
                Log.Print("NCamera_Preview Exception: " + ex.Message);
            }

        }

        public virtual void OnshowPreview(DisplayImageEventArgs e)
        {
            if (showPreview != null)
                showPreview(this, e);
        }
        #endregion

        #region Biometrics Functions

        /// <summary>
        /// Regeresa el template solicitado de la imagen. (Se debe mover el resize de las biometrías a Process para respetar la verdadera función de esta).
        /// </summary>
        /// <param name="fimage"> Imagen del biométrico. </param>
        /// <param name="format"> Formato solicitado. </param>
        /// <returns> Template en formato solicitado. </returns>
        private byte[] getRecordFromImg(NImage fimage, NImageFormat format)
        {

            if (format == NImageFormat.Jpeg) //Realiza el resize de la imagen del rostro para el Api Connect
            {
                int x = (int)fimage.Width;
                int y = (int)fimage.Height;
                Bitmap bitmap = new Bitmap(480, 640);
                float scale = Math.Min(480 / x, 640 / y);
                using (Graphics graph = Graphics.FromImage(bitmap))
                {
                    Rectangle ImageSize = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
                    graph.FillRectangle(Brushes.White, ImageSize);
                }
                // Create graphics object on that image
                Graphics graphics = Graphics.FromImage(bitmap);

                NBuffer imgBuff = fimage.Save(NImageFormat.Bmp);
                using (var ms = new MemoryStream(imgBuff.ToArray()))
                {
                    Image inputImage = Bitmap.FromStream(ms);

                    var scaleWidth = (int)(x * scale);
                    var scaleHeight = (int)(y * scale);

                    //graphics.DrawImage(inputImage, (480 - x) / 2, (640 - y) / 2, x, y);
                    graphics.DrawImage(inputImage, ((int)x - scaleWidth) / 2, ((int)y - scaleHeight) / 2, scaleWidth, scaleHeight);

                    // save the created image
                    using (var stream = new MemoryStream())
                    {
                        Bitmap resized = new Bitmap(inputImage, new Size(480, 640));
                        //resized.SetResolution(300,300);
                        //resized.Save(@"C:\BiometricNIST\ROSTRORECTIFICADO.bmp");
                        resized.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);
                        // Dispose the graphics object
                        NImage imgGemal = NImage.FromMemory(stream.ToArray());
                        //imgGemal = NImage.FromImage(NPixelFormat.Grayscale8S, 0, imgGemal);
                        NBuffer buffer = imgGemal.Save(NImageFormat.Jpeg);
                        graphics.Dispose();
                        bitmap.Dispose();
                        inputImage.Dispose();
                        return buffer.ToArray();
                    }


                }
            }
            else if (format == NImageFormat.Bmp) //Realiza el resize de la huella para el Api Connect
            {
                // Create blank image
                int x = (int)fimage.Width;
                int y = (int)fimage.Height;
                Bitmap bitmap = new Bitmap(416, 416);
                using (Graphics graph = Graphics.FromImage(bitmap))
                {
                    Rectangle ImageSize = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
                    graph.FillRectangle(Brushes.White, ImageSize);
                }
                // Create graphics object on that image
                Graphics graphics = Graphics.FromImage(bitmap);

                NBuffer imgBuff = fimage.Save(NImageFormat.Bmp);
                using (var ms = new MemoryStream(imgBuff.ToArray()))
                {
                    Image inputImage = Bitmap.FromStream(ms);
                    Bitmap bmpfinger = new Bitmap(x, 416);

                    Graphics g = Graphics.FromImage(bmpfinger);

                    // Draw the given area (section) of the source image
                    // at location 0,0 on the empty bitmap (bmp)
                    g.DrawImage(inputImage, 0, 0, x, y);
                    // Load an image from existing file
                    graphics.DrawImage(bmpfinger, (416 - x) / 2, 0, x, 416);

                    // save the created image
                    using (var stream = new MemoryStream())
                    {
                        bitmap.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);
                        // Dispose the graphics object
                        NImage imgGemal = NImage.FromMemory(stream.ToArray());
                        imgGemal = NImage.FromImage(NPixelFormat.Grayscale8S, 0, imgGemal);
                        NBuffer buffer = imgGemal.Save(NImageFormat.Bmp);
                        graphics.Dispose();

                        // Dispose the images
                        bitmap.Dispose();
                        inputImage.Dispose();
                        return buffer.ToArray();
                    }


                }
            }
            else if (format == NImageFormat.Jpeg2K) //Recupera solo el BMP de el biométrico
            {
                NBuffer imgBuff = fimage.Save(NImageFormat.Bmp);
                return imgBuff.ToArray();
            }
            else
            {
                NBuffer imgBuff = fimage.Save(format);
                return imgBuff.ToArray();
            }
        }

        private byte[] getRecordFromImgForOneFinger(NImage fimage, NImageFormat format)
        {
            NBuffer buffer = fimage.Save(NImageFormat.Bmp);
            NImage imagegigante = NImage.FromMemory(buffer);
            NFinger fingergigante = new NFinger();
            fingergigante.Image = imagegigante;
            NSubject otrosubject = new NSubject();
            otrosubject.Fingers.Add(fingergigante);
            NBiometricClient otroclient = new NBiometricClient();
            NBiometricTask task = otroclient.CreateTask(NBiometricOperations.Segment | NBiometricOperations.CreateTemplate, otrosubject);
            otroclient.PerformTask(task);
            if (task.Status == NBiometricStatus.Ok)
            {
                //otrosubject.fingers[1].Image.Save(@"C:\BiometricNIST\huellagigante.bmp",NImageFormat.Bmp);
                buffer = otrosubject.Fingers[1].Image.Save(NImageFormat.Bmp);
                return buffer.ToArray();
            }
            return null;
        }

        private byte[] getWSQFromArray(byte[] BMPFinger)
        {
            NImage ImageCaptured = NImage.FromMemory(BMPFinger);
            try
            {
                using (NSubject referenceSubject = new NSubject())
                using (var FingerCaptured = new NFinger())
                {
                    FingerCaptured.Image = ImageCaptured;
                    NBuffer imgBuff = FingerCaptured.Image.Save(NImageFormat.Wsq);
                    Log.Print("WSQ CREATED.");
                    return imgBuff.ToArray();
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public static Bitmap ResizeImage(Bitmap imgToResize, Size size)
        {
            try
            {
                Bitmap b = new Bitmap(size.Width, size.Height);
                using (Graphics g = Graphics.FromImage((Image)b))
                {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    g.DrawImage(imgToResize, 0, 0, size.Width, size.Height);
                }
                return b;
            }
            catch
            {
                Log.Print("Bitmap could not be resized");
                return imgToResize;
            }
        }


        /// <summary>
        /// Relaciona el NfiqQuality con el score que le corresponde.
        /// </summary>
        /// <param name="quality"> Calidad de la imagen. </param>
        /// <returns> String con el score de la calidad. </returns>
        private int getIntNFIQ(NfiqQuality quality)
        {
            if (quality == NfiqQuality.Unknown)
                return (int)NfiqQuality.Poor;
            return (int)quality;
        }

        /// <summary>
        /// Se solicita un task para evaluar la calidad de la huella.
        /// </summary>
        /// <param name="biometricClient"> Cliente Biometrico. </param>
        /// <param name="subject"> Subject que contiene el arreglo de huellas. </param>
        /// <returns> Score de NfiqQuality </returns>
        private int getNFIQ(NBiometricClient biometricClient, NImage image, NFPosition pos)
        {
            NSubject fingerSubject = new NSubject();
            NFinger fingerImage = new NFinger();
            fingerImage.Image = image;
            fingerSubject.Fingers.Add(fingerImage);

            Log.Print("Task: AssessQuality");
            NBiometricTask task = biometricClient.CreateTask(NBiometricOperations.AssessQuality, fingerSubject);

            //Perform task
            biometricClient.PerformTask(task);
            NBiometricStatus status = task.Status;
            if (status == NBiometricStatus.Ok)
            {
                //NFIQ 1.0
                //value can be 20 (poor), 40 (fair), 60 (good), 80 (very good), 100 (excellent),
                //     254 (NFIQ 1.0 was not calculated) and
                //     255 (failed to calculate NFIQ 1.0 value).

                //NFIQ 2.0
                //value can be from interval [0; 100],
                //  254 (NFIQ 2.0 was not calculated) and
                //  255 (failed to calculate NFIQ 2.0 value).

                //Use NBiometricTypes.Nfiq1ToNfiqQuality to convert NFIQ 1.0 to Neurotec.Biometrics.NfiqQuality.
                //Use NBiometricTypes.NfiqQualityToNfiq1 to convert Neurotec.Biometrics.NfiqQuality to NFIQ 1.0. 


                var nfiQA = NBiometricTypes.Nfiq1ToNfiqQuality(fingerSubject.Fingers[0].Objects[0].Quality);

                Log.Print("NFIQ extracted successfully");
                Log.Print($"Finger quality is: {nfiQA} value: {fingerSubject.Fingers[0].Objects[0].Quality} ", nfiQA);

                #region NFIQ GEMALTO

                //CogentFingerQuality gemaltoNFIQ = new CogentFingerQuality();
                //NImage imgGemal = NImage.FromImage(NPixelFormat.Grayscale8S, 0, finger.fingers[0].Image);
                //imgGemal = NImage.FromMemory(getRecordFromImg(imgGemal, NImageFormat.Bmp));
                //imgGemal = NImage.FromImage(NPixelFormat.Grayscale8S, 0, imgGemal);
                //imgGemal.Save(@"C:\BiometricNIST\" + (int)pos + "GRAY.bmp", NImageFormat.Bmp);
                //NBuffer buffer = imgGemal.Save(NImageFormat.Bmp);
                //int calif = gemaltoNFIQ.CheckNFIQ(buffer.ToArray(), (uint)416, (uint)416, (int)pos);
                //gemaltoNFIQ = null;
                //return getIntNFIQ((NfiqQuality)calif);

                #endregion
                return (int)nfiQA;
            }
            else
            {
                Log.Print("Quality assesment failed: {0}", status);
                return (int)NfiqQuality.Poor;
            }
        }

        /// <summary>
        /// Se solicita un task para evaluar la calidad de la huella.
        /// </summary>
        /// <param name="biometricClient"> Cliente Biometrico. </param>
        /// <param name="finger"> Subject que contiene el arreglo de huellas. </param>
        /// <returns> Score de NfiqQuality </returns>
        private int getNFIQ(NFinger finger)
        {

            if (finger.Objects[0].Quality != 254 || finger.Objects[0].Quality != 255)
            {
                //NFIQ 1.0
                //value can be 20 (poor), 40 (fair), 60 (good), 80 (very good), 100 (excellent),
                //     254 (NFIQ 1.0 was not calculated) and
                //     255 (failed to calculate NFIQ 1.0 value).

                //NFIQ 2.0
                //value can be from interval [0; 100],
                //  254 (NFIQ 2.0 was not calculated) and
                //  255 (failed to calculate NFIQ 2.0 value).

                //Use NBiometricTypes.Nfiq1ToNfiqQuality to convert NFIQ 1.0 to Neurotec.Biometrics.NfiqQuality.
                //Use NBiometricTypes.NfiqQualityToNfiq1 to convert Neurotec.Biometrics.NfiqQuality to NFIQ 1.0. 
                var nfiQA = NfiqQuality.Poor;

                var nfiq10 = finger.Objects[0].Values.Where(x => x.Name == "Nfiq10").ToList();

                if (nfiq10.Count > 0)
                {
                    var nfiq10Value = nfiq10.First().Value;

                    nfiQA = NBiometricTypes.Nfiq1ToNfiqQuality(nfiq10Value);

                    Log.Print("NFIQ extracted successfully");
                    Log.Print($"Finger quality is: {nfiQA} NFIQ1: {nfiq10Value} NFIQ 2.0 {finger.Objects[0].Quality} ");

                }
                return (int)nfiQA;
            }
            else
            {
                Log.Print($"Quality assesment failed {finger.Objects[0].Quality}");
                return (int)NfiqQuality.Poor;
            }
        }

        /// <summary>
        /// Indica si la huella fue capturada correctamente al tratar de generar un template individual
        /// </summary>
        /// <param name="biometricClient"></param>
        /// <param name="image"></param>
        /// <returns>Resultado de la generación del template</returns>
        private bool SingleFingerTemplates(NBiometricClient biometricClient, byte[] image)
        {
            try
            {
                NSubject ImageSubject = new NSubject();
                NFinger ImageNFinger = new NFinger();
                ImageNFinger.Image = NImage.FromMemory(image);
                ImageSubject.Fingers.Add(ImageNFinger);
                if (biometricClient.CreateTemplate(ImageSubject) != NBiometricStatus.Ok)
                    return true;
                return false;
            }
            catch (Exception ex)
            {
                return true;
            }
        }

        /// <summary>
        /// Crea los objetos DataFinger y los añade a la lista.
        /// </summary>
        /// <param name="pos"> Posición de la huella. </param>
        /// <param name="Fingers"> Lista de huellas a llenar con sus datos. </param>
        /// <param name="subject"> Objeto NSubject </param>
        /// <param name="nfPosition"> Posición de la/s huella/s. </param>
        /// <param name="biometricClient"> Objeto NBiometricClient. </param>
        private void CreateFingers(int pos, List<DataFinger> Fingers, NSubject subject, NFPosition nfPosition, NBiometricClient biometricClient, bool esEscanerUnidactilar)
        {
            int i;
            //Cuando es una captura de más de una huella, el arreglo "finger.fingers" va a contener en el indice cero la imagen de todas las huellas
            //En las siguientes posiciones ya trae las imagenes de cada una de las huellas por separado
            //"esEscanerUnidactilar" indica si se esta usando un sensor unidactilar o si es el de varias huellas,
            //Debido a lo anterior es que si se esta usando el sensor de varias huellas no se considera el primer elemento del arreglo, ya que es la imagen de todas las huellas capturadas
            if (esEscanerUnidactilar)
                i = 0;
            else
                i = 1;

            for (; i < subject.Fingers.Count; i++)
            {
                NFinger Finger = subject.Fingers[i];
                //Si la huella no contuvo muchas minusias, esta tambien será descartada
                if (Finger.Status == NBiometricStatus.TooFewFeatures || Finger.Status == NBiometricStatus.BadObject || Finger.Status == NBiometricStatus.SpoofDetected)
                    continue;

                DataFinger fingerData = new DataFinger();
                NImage image = Finger.Image;
                Log.Print("Finger Status: " + Finger.Status);
                #region Extraemos toda la info de la huella
                fingerData.Manufacturer = biometricClient.FingerScanner.Make;
                fingerData.Serial = biometricClient.FingerScanner.SerialNumber;
                fingerData.Model = biometricClient.FingerScanner.Model;
                fingerData.WSQ = getRecordFromImg(image, NImageFormat.Wsq);
                fingerData.Nfiq = getNFIQ(Finger);
                fingerData.BMP = getRecordFromImg((NImage)image, NImageFormat.Bmp);
                fingerData.Hash = SHA256HexHashString(fingerData.BMP).ToUpper();
                fingerData.Jpeg2000 = getRecordFromImg((NImage)image, NImageFormat.Jpeg2K);
                /* Para obtener los WSQ
                String path = "C:/Users/z425263/OneDrive - Santander Office 365/Escritorio/WSQ/huella"+ (int)Finger.Position+".jpg";
            String pathWSQ = "C:/Users/z425263/OneDrive - Santander Office 365/Escritorio/WSQ/huella" + (int)Finger.Position + ".wsq";
            System.IO.File.WriteAllBytes(path, fingerData.Jpeg2000);
                System.IO.File.WriteAllBytes(pathWSQ, fingerData.WSQ);

                */
                fingerData.Position = (int)Finger.Position;

                fingerData.Neuro_template = GetTemplateByNFinger(fingerData.Jpeg2000, biometricClient);

                //Image newImageWSQ = byteArrayToImage(fingerData.WSQ);
                //Image newImageBMP = byteArrayToImage(fingerData.BMP);
                //Image newImageJpeg2000 = byteArrayToImage(fingerData.Jpeg2000);

                // newImageWSQ.Save("C:/Source/GitLab/biocheck/Biocheck/BA.Biocheck.SignalR/img/imgWSQ.wsq", ImageFormat.);
                //    newImageBMP.Save("C:/Source/GitLab/biocheck/Biocheck/BA.Biocheck.SignalR/img/imgBMP.bmp", ImageFormat.Bmp);
                //newImageJpeg2000.Save("C:/Source/GitLab/biocheck/Biocheck/BA.Biocheck.SignalR/img/imgJpeg200.jpeg2000", ImageFormat.Jpeg);

                //File.WriteAllBytes("C:/Source/GitLab/biocheck/Biocheck/BA.Biocheck.SignalR/img/imgWSQ.wsq", fingerData.WSQ);
                //File.WriteAllBytes("C:/Source/GitLab/biocheck/Biocheck/BA.Biocheck.SignalR/img/imgBMP.bmp", fingerData.BMP);
                //File.WriteAllBytes("C:/Source/GitLab/biocheck/Biocheck/BA.Biocheck.SignalR/img/imgJpeg200.jpeg2000", fingerData.Jpeg2000);

                #endregion
                Fingers.Add(fingerData);
            }

        }

        private byte[] GetTemplateByNFinger(byte[] imageFingerprint, NBiometricClient biometricClient)
        {

            using (var subject = new NSubject())
            using (var finger = new NFinger())
            {

                NImage ImageCaptured = NImage.FromMemory(imageFingerprint);

                finger.Image = ImageCaptured;
                finger.Position = NFPosition.Unknown;

                subject.Fingers.Add(finger);

                biometricClient.CreateTemplate(subject);

                return subject.GetTemplate().Save().ToArray();

            }
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            // Image img = new Image;
            try
            {
                MemoryStream ms = new MemoryStream(byteArrayIn, 0, byteArrayIn.Length);
                ms.Write(byteArrayIn, 0, byteArrayIn.Length);
                return Image.FromStream(ms);
            }
            catch { return null; }
            //     return returnImage;
        }

        public void wsq()
        {

            //Write bytes to disk
            // File.WriteAllBytes(@"C:\Users\Admin\Desktop\bytesWSQ512.wsq", bytesWSQ512);

        }

        /// <summary>
        /// Realiza la converión a hexadecimal del arreglo
        /// </summary>
        /// <param name="bytes">Arreglo a convertir</param>
        /// <param name="upperCase">Bandera para generar el hexadecimal con mayúsculas</param>
        /// <returns>Arreglo en hexadecimal</returns>
        private string ToHex(byte[] bytes, bool upperCase)
        {
            StringBuilder result = new StringBuilder(bytes.Length * 2);
            for (int i = 0; i < bytes.Length; i++)
                result.Append(bytes[i].ToString(upperCase ? "X2" : "x2"));
            return result.ToString();
        }
        /// <summary>
        /// Genera el hash con sha256
        /// </summary>
        /// <param name="wsq">Imagen del biométrico</param>
        /// <returns>Hash en hexadecimal</returns>
        private string SHA256HexHashString(byte[] wsq)
        {
            using (var sha256 = SHA256Managed.Create())
            {
                var hash = sha256.ComputeHash(wsq);
                return ToHex(hash, false);
            }
        }

        /// <summary>
        /// Crea los objetos DataFinger y los añade a la lista.
        /// </summary>
        /// <param name="pos"> Posición del iris. </param>
        /// <param name="ListIrises"> Lista de Iris a llenar con sus datos. </param>
        /// <param name="subject"> Objeto NSubject </param>
        /// <param name="nfPosition"> Posición de iris/es. </param>
        /// <param name="biometricClient"> Objeto NBiometricClient. </param>
        private byte[] CreateIris(int pos, List<DataIris> ListIrises, NSubject subject, NEPosition nePosition, NBiometricClient biometricClient, byte[] BMP)
        {
            foreach (NIris Iris in subject.Irises)
            {
                DataIris irisData = new DataIris();
                NImage image = Iris.Image;

                irisData.Manufacturer = biometricClient.IrisScanner.Make;
                irisData.Serial = biometricClient.IrisScanner.SerialNumber;
                irisData.Model = biometricClient.IrisScanner.Model;
                //irisData.WSQ = getRecordFromImg(image, NImageFormat.Wsq);
                irisData.BMP = getRecordFromImg((NImage)image, NImageFormat.Bmp);
                irisData.Jpeg2000 = getRecordFromImg((NImage)image, NImageFormat.Jpeg2K);

                switch (nePosition)
                {
                    case NEPosition.Left:
                        irisData.Position = "LEFT_EYE";
                        break;
                    case NEPosition.Right:
                        irisData.Position = "RIGHT_EYE";
                        break;
                }

                ListIrises.Add(irisData);

            }
            return BMP;
        }

        #endregion

        #endregion

        public string InstructionActual = string.Empty;
        public bool _modoTestFace = false;
    }
}
