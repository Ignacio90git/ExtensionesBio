﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using CogentSystems.Sdks.SeqQuaChk;
using System.Drawing;
using System.IO;

namespace BA.Biocheck.Neurotechnology.v13
{
    public class CogentFingerQuality
    {
        //public int CheckNFIQ(byte[] fingerimage, uint height, uint width, int pos)
        //{
        //    using (var ms = new MemoryStream(fingerimage))
        //    {
        //        Bitmap bmp = new Bitmap(ms);
        //        bmp.Save(@"C:\BiometricNIST\" + pos + ".bmp");
        //    }

        //    string pass = "Password";
        //    int nRet;
        //    byte byCoreQuality = 0x00;
        //    byte byOverallQuality = 0x00;
        //    const int MNT_1K_LENGTH = 1024;
        //    string strError = "";
        //    int nRetCode = CsiTools.CsiToolsExp_SetPassword(pass);
        //    if (nRetCode != 0)
        //    {
        //        Logger.Log("Error: CsiToolsExp_SetPassword failed, error code = " + nRetCode);
        //        return -1;
        //    }

        //    nRetCode = P2uEnPrcsFpp.ExEnPrcsFPP_SetPassword(pass);
        //    if (nRetCode != 0)
        //    {
        //        Logger.Log("Error: ExEnPrcsFPP_SetPassword failed, error code = " + nRetCode);
        //        return -1;
        //    }

        //    nRetCode = P2uMatchEn.VerifyEn_SetPassword(pass);
        //    if (nRetCode != 0)
        //    {
        //        Logger.Log("Error: VerifyEn_SetPassword failed, error code = " + nRetCode);
        //        return -1;
        //    }
        //    P2uEnPrcsFpp.ExEnPrcsFPP_SetEnv("..\\data\\");
        //    P2uMatchEn.VerifyEn_SetEnv("..\\data\\");

        //    nRet = (int)CsiTools.Dib2Img(@"C:\BiometricNIST\2GRAY.bmp", @"C:\BiometricNIST\2GRAY.img", pos, "flat");  // 14 is the finger number of left flat slap
        //    if (nRet < 0)
        //    {
        //        //Logger.Log("Error: Fail to convert BMP file " + strFlatFile + " to raw image file, error code " + nRet);
        //        Logger.Log("Please run the program with admin privilege");
        //        return nRet;
        //    }
        //    //Logger.Log("Info: Convert BMP file " + strFlatFile + " to raw image file");
        //    byte[] ucMntFlat = new byte[MNT_1K_LENGTH];
        //    //ucMntFlat[0] = new byte[MNT_1K_LENGTH];
        //    OLD_IMG_HEAD aImgHeadFlats = new OLD_IMG_HEAD();
        //    aImgHeadFlats.column = (ushort)width;
        //    aImgHeadFlats.line = (ushort)height;
        //    aImgHeadFlats.resolution = 500;
        //    aImgHeadFlats.fingernum = (byte)(pos); //11 - 20 are the finger number for split flat fingers
        //    nRet = P2uEnPrcsFpp.ExEnPrcsFPP_WQ(
        //                ref aImgHeadFlats,
        //                ReadFile(@"C:\BiometricNIST\2GRAY.img"),
        //                FingerImpressionType.LiveScanPlain,
        //                ucMntFlat,
        //                MNT_1K_LENGTH,
        //                ref byCoreQuality,
        //                ref byOverallQuality,
        //                ref strError
        //                );
        //    if (nRet < 0)
        //    {
        //        Logger.Log("Error: ExEnPrcsFPP_Ex failed to process flat image, error code " + nRet);
        //        return nRet;
        //    }
        //    else
        //        Logger.Log("Info: Quality of flat image = " + nRet + ", core quality = " + byCoreQuality + ", overall quality = " + byOverallQuality);
            
        //    return nRet;
        //}

        //public byte[] ReadFile(string strInputFileName)
        //{
        //    using (Stream stream = new FileStream(strInputFileName, System.IO.FileMode.Open))
        //    {
        //        byte[] result = new byte[stream.Length];
        //        stream.Read(result, 0, result.Length);
        //        stream.Close();
        //        return result;
        //    }
        //}

        //public void SegmentFingers()
        //{
        //    //// Get the cut flat finger images from flat slap
        //    //Logger.Log("Info: Get the cut flat finger images from flat slap ...");
        //    //byte[][] imageBuffers = new byte[4][];
        //    //imageBuffers[0] = new byte[aCropDim[0].width * aCropDim[0].height];
        //    //imageBuffers[1] = new byte[aCropDim[1].width * aCropDim[1].height];
        //    //imageBuffers[2] = new byte[aCropDim[2].width * aCropDim[2].height];
        //    //imageBuffers[3] = new byte[aCropDim[3].width * aCropDim[3].height];

        //    //for (int i = 0; i < 4; i++)
        //    //{
        //    //    Logger.Log("Info: #" + i + ", width: " + aCropDim[i].width + ", height: " + aCropDim[i].height);
        //    //    nRet = CsiTools.SaveOneClippedFlatImage(ref imgHeadTmp, byFlatImgs, ref aCropDim[i], imageBuffers[i]);
        //    //    if (nRet < 0)
        //    //    {
        //    //        Logger.Log("Error:   SaveOneClippedFlatImage: error code " + nRet);
        //    //        return nRet;
        //    //    }
        //    //    else
        //    //        Logger.Log("Info:   SaveOneClippedFlatImage (image #" + i + ") completed successfully!");

        //    //    int nWidth = 0;
        //    //    int nHeight = 0;

        //    //    // Get the actual size of segmented flat finger
        //    //    nRet = CsiTools.GetFingerImpressionSize(imageBuffers[i],
        //    //                                   aCropDim[i].width,
        //    //                                   aCropDim[i].height,
        //    //                                   1,
        //    //                                   ref nWidth,
        //    //                                   ref nHeight);
        //    //    aFlatFingerSize[i] = new FlatFingerSize();
        //    //    aFlatFingerSize[i].width = nWidth;
        //    //    aFlatFingerSize[i].height = nHeight;
        //    //    if (nRet < 0)
        //    //    {
        //    //        Logger.Log("Error:   GetFingerImpressionSize: error code " + nRet);
        //    //        return nRet;
        //    //    }
        //    //    else
        //    //        Logger.Log("Info:   Size of flat finger impression " + i + ", width = " + aFlatFingerSize[i].width + ", height = " + aFlatFingerSize[i].height);
        //    //}
        //}
    }
}
