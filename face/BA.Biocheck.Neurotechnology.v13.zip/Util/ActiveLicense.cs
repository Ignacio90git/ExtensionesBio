﻿using BA.Biocheck.Core.Common.Util;
using BA.LogRegister;
using Neurotec.Licensing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BA.Biocheck.Neurotechnology.v13.Util
{
    public static class ActiveLicense
    {
        #region properties
        private static string pathSerials { get; set; }
        private static string pathSaveLic { get; set; }
        private static string nameLic { get; set; }
        #endregion

        /// <summary>
        /// Activacion de licencias.
        /// </summary>
        /// <param name="_pathSerials">Ubicacion del archivo que contiene las llaves</param>
        /// <param name="_pathSaveLic">Directorio donde se guardaran las licencias</param>
        /// <param name="_nameLic">Nombre que se asignará a las licencias</param>
        /// <returns></returns>
        public static bool ActiveLicenseNeuro(string _pathSerials, string _pathSaveLic, string _nameLic)
        {
            //En el archivo ActiveLicense/serials.txt" se guardan las licencias que debend de ser activadas
            //En los archivos: "Active\Licenses\BALicenceNeurotechnology#.lic" indica las licencias que ya estan activadas
            pathSerials = _pathSerials;
            pathSaveLic = _pathSaveLic;
            nameLic = _nameLic;
            //Obtien los archivos que indican las licencias activadas, cada archivo corresponde a una licencia. Ruta:Active\Licenses\BALicenceNeurotechnology#.lic
            var lFiles = GetLicenseFiles(pathSaveLic);
            //Obtiene las licencias que faltan por activar, de acuerdo a las licencias que indica el archivo "ActiveLicense/serials.txt"
            var lst = GetSerialFile(pathSerials, lFiles);

            return Activation(lst);
        }

        private static bool Activation(List<SerialNumber> lst)
       {
           var resp = false;
           try
           {
               Log.Enter();
               Log.Division();
               Log.LogImportant("Comenzando proceso de activación de licencias. ");

               //Se revisa que el directorio de guardado exista
               CheckPath(pathSaveLic);

               //Se validan las direcciones de archivo de licencias y guardado de .lic
               if (pathSaveLic == string.Empty || pathSerials == string.Empty)
                   Log.LogError("Los datos obtenidos son incorrectos");
               else
               {


                   foreach (var a in lst)
                   {
                       ///Generate data from serial number
                       var data = GenerateId(a.serial);

                       //Se envia Id generado a Neuro para obtener la licencia
                       var lic = ActiveLicence(data);

                       //Se escribe información obtenida de neuro en archivo .lic
                       WriteFile(Path.Combine(pathSaveLic, string.Format("{0}{1}.{2}", nameLic, a.id, "lic")), lic);

                   }

                   resp = true;

               }
           }
           catch (Exception ex)
           {
               if (ex.ToString().Contains("Host desconocido"))
                   Log.LogError("Active license no puede acceder al servicio de activación, verifique configuración de firewall y antivirus.");
               else
                   Log.LogError("Activation Error: {0} ", ex.ToString());


           }
           return resp;
       }

        /// <summary>
        /// Veririca la existencia del directorio proporcionado, en caso de no existir se crea
        /// </summary>
        /// <param name="path"></param>
        public static void CheckPath(string path)
        {
            try
            {
                Log.Print("Validando ruta de guardado de licencias.");
                if (!Directory.Exists(path))
                {
                    Log.Print("Creando ruta de guardado de licencias.");
                    Directory.CreateDirectory(path);
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Generate Id with serial
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private static string GenerateId(string data)
        {
            try
            {
                Log.Print("Generando Id...");
                /* Either point to correct place for id_gen.exe, or pass NULL or use method without idGenPath parameter in order to search id_gen.exe in current folder */
                return NLicense.GenerateId(data);

            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        /// <summary>
        /// Write in file 
        /// </summary>
        /// <param name="path"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public static bool WriteFile(string path, string data)
        {
            try
            {
                /* Write generated id to file */
                File.WriteAllText(path, data);

                Log.Print("Licencia guardada en: {0}", path);
                return true;
            }
            catch (Exception ex)
            {

                throw (ex);
            }
        }

        /// <summary>
        /// Activated license from internet
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private static string ActiveLicence(string data)
        {
            try
            {
                Log.Print("Activando Licencia.");
                /* Either point to correct place for id_gen.exe, or pass NULL or use method without idGenPath parameter in order to search id_gen.exe in current folder */

                return NLicense.ActivateOnline(data);

            }
            catch (Exception ex)
            {
                throw (ex);
            }

        }

        /// <summary>
        /// Get serials in list string from File
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private static List<string> GetLicenseFiles(string path)
        {
            var lstResp = new List<string>();

            Log.Print("Obteniendo Archivos .lic");

            int counter = 0;

            try
            {
                if (Directory.Exists(path))
                {
                    DirectoryInfo d = new DirectoryInfo(path);



                    FileInfo[] Files = d.GetFiles("*.lic"); //Getting Text files

                    foreach (FileInfo file in Files)
                    {
                        Console.WriteLine("{0} .- {1} ", counter, file.Name);
                        lstResp.Add(file.Name);
                        counter++;
                    }


                    Log.LogImportant("Se encontraron {0} licencias activadas.", counter);
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            return lstResp;
        }

        /// <summary>
        /// Get serials in list string from File
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private static List<SerialNumber> GetSerialFile(string path, List<string> lsFiles)
        {
            var lstResp = new List<SerialNumber>();
            if (File.Exists(path))
            {
                int counter = 0, counterBad = 0;
                string line;
                // Read the file and display it line by line.  
                using (var file = new StreamReader(path))
                {

                    try
                    {

                        //B6DF-30F8-4BB5-AAC3-72E4-C7EF-82D8-6574
                        while ((line = file.ReadLine()) != null)
                        {
                            var lineSp = line.Split(' ');
                            if (lineSp.Length > 1)
                            {
                                var nameFile = string.Format("{0}{1}.{2}", nameLic, lineSp[0].ToString(), "lic");
                                //Si aún no existe el archivo "BALicenceNeurotechnology#.lic", entonces esa licencia debe de ser activada y la guardamos en la lista lstResp
                                if (!lsFiles.Exists(x => x == nameFile))
                                    if (lineSp[1].Length == 39)
                                    {

                                        lstResp.Add(new SerialNumber(lineSp[0], lineSp[1]));
                                        Log.Print(line);
                                        counter++;
                                    }
                                    else
                                    {
                                        counterBad++;
                                        Log.LogError("Serial con formato incorrecto.");
                                    }
                            }
                            else
                            {
                                counterBad++;
                                Log.LogError("Línea del archivo serial con formato incorrecto.");

                            }


                        }


                        Log.LogImportant("Se encontraron {0} keys pendientes por activar.", lstResp.Count);
                        file.Close();
                    }
                    catch (Exception ex)
                    {
                        throw (ex);
                    }
                    finally
                    {
                        file.Dispose();
                    }
                }
            }
            else
            {
                Log.Print("Archivo de licencias no encontrado.");
            }
            return lstResp;
        }
    }

    internal class SerialNumber
    {
        public SerialNumber(string _id, string _serial)
        {
            id = _id;
            serial = _serial;
        }
        public string id { get; set; }
        public string serial { get; set; }
    }
}
